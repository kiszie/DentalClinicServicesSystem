<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Officer_Controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
       /*function index(){ 
	 	{
		$this->load->view('pateint_regis');
		}
	 	
		function save(){
            $this->load->model('Officer_Model');        
            if($this->input->post('submit')){
                $this->Officer_Model->process();                
                }
           redirect('Officer_Controller');
            }
        }*/
		
	/*function index()
	{
	$this->load->view('patient_regis');// loading form view
	}

	function p_regis()
	{
	$this->load->model('Officer_Model');
	$this->Officer_Model->p_regis();*/
	//$this->load->view('all_patient');//loading success view
	public function register_p(){
		$data = array(
		"result"=>$this->db->get('patient'),);
		
		$this->load->view('all_patient',$data);

}
}
	   
