<?php
class Officer_Model extends CI_Model { 

	    function showall(){
	    $this->load->database();
		$query = $this->db->get("patient");
}
        function p_regis()
{
	$data = array(
               'patientID '=> $PatientID,
               'Firstname' => $Firstname,
               'Surname' => $Surname,
				 'Age'=>$Age,
				 'Gender'=>$Gender,
				 'Treatment'=>$Treatment,
				 'Address'=>$Address,
				 'Tel'=>$Tel,
				 'Email'=>$Email);
/*$PatientID = $_POST['PatientID '];
$Firstname = $_POST['Firstname'];
$Surname = $_POST['Surname'];
$Age= $_POST['Age'];
$Gender= $_POST['Gender'];
$Treatment= $_POST['Treatment'];
$Address= $_POST['Address'];
$Tel= $_POST['Tel'];
$Email= $_POST['Email'];*/

$this->db->insert('patient', $data); 

/*$order= "insert into patient(pateintID,Firstname,Surname,Age,Gender,Treatment,Address,Tel,Email) VALUES('$PatientID','$Firstname','$Surname','$Age','$Gender','$Treatment','$Address','$Tel','$Email)";

$this->db->query($order);*/
     ECHO "CORRECT?";
}
}
?>

	