<?php
require_once APPPATH."manage/Officer_manage.php";

class TestOfficer_manage extends CI_controller{
	
	public function testLogin(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_user_1 = "xxxx";
		$in_pass_1 = "xxxx";
		$expResult1 = false;
		
		$actResult1 = $officer->login($in_user_1, $in_pass_1);
		echo $this->unit->run($expResult1, $actResult1, "test login -> false case");
		
		$in_user_2 = "admin";
		$in_pass_2 = "1234";
		$expResult2 = true;
		
		$actResult2 = $officer->login($in_user_2, $in_pass_2);
		echo $this->unit->run($expResult2, $actResult2, "test login -> true case");
		}
		
	public function testget_p_db(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->patientID = 'P0001';
		$x->password = '1234';
		$x->Firstname = 'xxxx';
		$x->Surname = 'xxxx';
		$x->Age = 33;
		$x->Gender = 2;
		$x->Treatment = 'xxx';
		$x->Address = 'xxxx';
		$x->Tel = '0000000000';
		$x->Email = 'xxxx@xxx.com';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->patientID = 'P0002';
		$x2->password = '1234';
		$x2->Firstname = 'xxxx';
		$x2->Surname = 'xxxx';
		$x2->Age = 23;
		$x2->Gender = 2;
		$x2->Treatment = 'xxx';
		$x2->Address = 'xxxx';
		$x2->Tel = '0000000000';
		$x2->Email = 'xxxx@xxx.com';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->patientID = 'P0003';
		$x3->password = '1234';
		$x3->Firstname = 'xxxx';
		$x3->Surname = 'xxxx';
		$x3->Age = 23;
		$x3->Gender = 2;
		$x3->Treatment = 'xxx';
		$x3->Address = 'xxxx';
		$x3->Tel = '0000000000';
		$x3->Email = 'xxxx@xxx.com';
		$expResult[2] = $x3;
		
		$actResult = $officer->get_p_db();
		
		echo $this->unit->run($expResult, $actResult, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
	}	
		
	public function testget_db(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->userID = 'test';
		$x->role = '0';
		$x->password = '1234';
		$x->f_name = 'aaaa';
		$x->l_name = 'xxxx';
		$x->address = 'xxxx';
		$x->email = 'xxxx@xxx.com';
		$x->telNum = '0000000000';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->userID = 'admin';
		$x2->role = 'admin';
		$x2->password = '1234';
		$x2->f_name = 'xxxx';
		$x2->l_name = 'xxxx';
		$x2->address = 'xxxx';
		$x2->email = 'xxxx@xxx.com';
		$x2->telNum = '0000000000';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->userID = 'dent001';
		$x3->role = '0';
		$x3->password = '1234';
		$x3->f_name = 'dddd';
		$x3->l_name = 'dddd';
		$x3->address = 'dddd';
		$x3->email = 'dddd@ddd.com';
		$x3->telNum = '1111111111';
		$expResult[2] = $x3;
		
		$actResult = $officer->get_db();
		
		echo $this->unit->run($expResult, $actResult, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}	
	public function testp_register(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$data = array(
		'patientID '=> $this->input->post('P0004'),
		'password'=> $this->input->post('1234'),
     	'Firstname' => $this->input->post('Paula'),
     	'Surname' => $this->input->post('Abdul'),
		'Age'=>$this->input->post(44),
		'Gender'=>$this->input->post(2),
		'Treatment'=>$this->input->post('Whitening'),
		'Address'=>$this->input->post('199 sun st., Honolulu, Hawaii, USA'),
		'Tel'=>$this->input->post('111111111'),
		'Email'=>$this->input->post('paula.a@aloha.com'),
		'submit'=>$this->input->post('submit'));
		
		$expResult = true;
		$actResult = $officer->p_register();
		echo $this->unit->run($expResult, $actResult, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testp_edit(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_1 = 'P0000';
		$expResult1 = null;	
		
		$actResult1 = $officer->p_edit($in_id_1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_2 = 'P0001';
		$expResult2 = array('patientID'=>'P0001','password'=>'1234','Firstname'=>'xxxx','Surname'=>'xxxx','Age'=>33,'Gender'=>2,'Treatment'=>'xxxx','Address'=>'xxxx','Tel'=>'0000000000','Email'=>'xxxx@xxx.com','submit'=>null);	
		
		$actResult2 = $officer->p_edit($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testp_delete(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_2 = '0';
		$expResult2 = true;
		$actResult2 = $officer->p_delete($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testd_register(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		$data = array(
    		'userID '=> $this->input->post('dent002'),
			'Role'=>$this->input->post('dentist'),
			'password'=> $this->input->post('1234'),
     		'f_name' => $this->input->post('dent'),
     		'l_name' => $this->input->post('tist'),
			'address'=>$this->input->post('clinic'),
			'telNum'=>$this->input->post('0000000000'),
			'email'=>$this->input->post('dentist.t@clinic.com'),
			'submit'=>$this->input->post('submit'));
		$expResult = true;
		$actResult = $officer->d_register($data);
		echo $this->unit->run($expResult, $actResult, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testd_edit(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_1 = 'P0000';
		$expResult1 = null;	
		
		$actResult1 = $officer->d_edit($in_id_1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_2 = 'test';
		$expResult2 = array('userID'=>'test','role'=>'0','password'=>'1234','f_name'=>'aaaa','l_name'=>'xxxx','address'=>'xxxx','email'=>'xxxx@xxx.com','telNum'=>'0000000000','submit'=>null);	
		
		$actResult2 = $officer->d_edit($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		public function testd_delete(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_2 = '0';
		$expResult2 = true;
		$actResult2 = $officer->d_delete($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testview_appointment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->appointmentID = 1;
		$x->patientID = '1';
		$x->userID = 'test';
		$x->aDate = '2014-06-08';
		$x->startTime = '13:00:00';
		$x->endTime = '13:30:00';
		$x->treatment = 'Bridge';
		$x->description = '-';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->appointmentID = 2;
		$x2->patientID = 'P0003';
		$x2->userID = 'test';
		$x2->aDate = '2014-06-09';
		$x2->startTime = '16:15:00';
		$x2->endTime = '16:45:00';
		$x2->treatment = 'Zeppline';
		$x2->description = '-';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->appointmentID = 15;
		$x3->patientID = 'P0004';
		$x3->userID = 'test';
		$x3->aDate = '2014-07-09';
		$x3->startTime = '22:00:00';
		$x3->endTime = '23:00:00';
		$x3->treatment = 'aaaa';
		$x3->description = 'aaaa';
		$expResult[2] = $x3;
		//Array ( [dbrow] => Array ( [0] => stdClass Object ( [appointmentID] => 1 [patientID] => 1 [userID] => test [aDate] => 2014-06-08 [startTime] => 13:00:00 [endTime] => 13:30:00 [treatment] => Bridge [description] => - ) [1] => stdClass Object ( [appointmentID] => 2 [patientID] => P0003 [userID] => test [aDate] => 2014-06-09 [startTime] => 16:15:00 [endTime] => 16:45:00 [treatment] => Zeppline [description] => - ) [2] => stdClass Object ( [appointmentID] => 15 [patientID] => P0004 [userID] => test [aDate] => 2014-07-09 [startTime] => 22:00:00 [endTime] => 23:00:00 [treatment] => aaaa [description] => aaaa ) [3] => stdClass Object ( [appointmentID] => 8 [patientID] => P0001 [userID] => 0 [aDate] => 2014-06-17 [startTime] => 14:00:00 [endTime] => 15:00:00 [treatment] => clean [description] => 300 thb ) ) )
		
		$x4 = $this->load->model('Offiecer_Model');
		$x4->appointmentID = 8;
		$x4->patientID = 'P0001';
		$x4->userID = '0';
		$x4->aDate = '2014-06-17';
		$x4->startTime = '14:00:00';
		$x4->endTime = '15:00:00';
		$x4->treatment = 'clean';
		$x4->description = '300 thb';
		$expResult[3] = $x4;
		$actResult = $officer->view_appointment();
		
		echo $this->unit->run($expResult, $actResult, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testmake_appointment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		$data = array(
    		'patientID'=> $this->input->post('P0002'),
			'userID'=>$this->input->post('dent001'),
			'aDate'=> $this->input->post('2014-07-04'),
    		'startTime' => $this->input->post('13:00:00'),
    		'endTime' => $this->input->post('13:30:00'),
			'treatment'=>$this->input->post('Whitening'),
			'description'=>$this->input->post('4500 THB'),
			'submit'=>$this->input->post('submit'));
		$expResult = true;
		$actResult = $officer->make_appointment($data);
		echo $this->unit->run($expResult, $actResult, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testapp_edit(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_1 = '3';
		$expResult1 = null;	
		
		$actResult1 = $officer->app_edit($in_id_1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_2 = '2';
		$expResult2 = array('appointmentID'=>2,'patientID'=>'P0003','userID'=>'test','aDate'=>'2014-06-09','startTime'=>'16:15:00','endTime'=>'16:45:00','treatment'=>'Zeppline','description'=>'-','submit'=>null);	
		
		$actResult2 = $officer->app_edit($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testapp_delete(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_2 = '22';
		$expResult2 = true;
		$actResult2 = $officer->app_delete($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);	
		}
	public function testPatientCalendar(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_1 = 'P0002';
		$expResult1 = null;
		$actResult1 = $officer->patientCalendar($in_id_1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_2 = 'P0001';
		//$expResult2 = array('appointmentID'=>8,'patientID'=>'P0001','userID'=>'0','aDate'=>'2014-06-17','startTime'=>'14:00:00','endTime'=>'15:00:00','treatment'=>'clean','description'=>'300 thb','submit'=>null);	
		$x = $this->load->model('Offiecer_Model');
		$x->appointmentID = 8;
		$x->patientID = 'P0001';
		$x->userID = '0';
		$x->aDate = '2014-06-17';
		$x->startTime = '14:00:00';
		$x->endTime = '15:00:00';
		$x->treatment = 'clean';
		$x->description = '300 thb';
		$x->submit = null;
		$expResult2[0] = $x;
		
		$actResult2 = $officer->patientCalendar($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		public function testDentistCalendar(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_1 = 'dent001';
		$expResult1 = null;
		$actResult1 = $officer->dentistCalendar($in_id_1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_2 = '0';
		//$expResult2 = array('appointmentID'=>8,'patientID'=>'P0001','userID'=>'0','aDate'=>'2014-06-17','startTime'=>'14:00:00','endTime'=>'15:00:00','treatment'=>'clean','description'=>'300 thb','submit'=>null);	
		$x = $this->load->model('Offiecer_Model');
		$x->appointmentID = 8;
		$x->patientID = 'P0001';
		$x->userID = '0';
		$x->aDate = '2014-06-17';
		$x->startTime = '14:00:00';
		$x->endTime = '15:00:00';
		$x->treatment = 'clean';
		$x->description = '300 thb';
		$x->submit = null;
		$expResult2[0] = $x;
		
		$actResult2 = $officer->dentistCalendar($in_id_2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	}

?>