<?php
class Offiecer_Model extends CI_Model {
	 
	public function get_data(){
	   	$this->load->database();
		$query = $this->db->get("clinic_user");
		if ( $query->num_rows() > 0 ) {
			$output['dbrow'] = $query->result();
		} else {
			$output['dbrow'] = null;
		}
		$query->free_result();
		//print_r($output);
		$this->load->view("o_all_dent", $output);
		return $output['dbrow'];
	   }
	   
	public function get_p_data(){
		$this->load->database();
		$query = $this->db->get("patient");
		if ( $query->num_rows() > 0 ) {
			$output['dbrow'] = $query->result();
		} else {
			$output['dbrow'] = null;
		}
		$query->free_result();
		//print_r($output);
		$this->load->view("o_all_patient", $output);
		return $output['dbrow'];
	   }
	   
	function addnew($data){
			$this->db->insert('patient', $data);
			return true;
		}
	
	function getDataById($userID){
		
		 
	$query = $this->db->get_where('clinic_user',array('userID'=>$userID));
	return $query->row_array();

	   }
	 
	 function get_p_DataById($patientID){
		
		 
	$query = $this->db->get_where('patient',array('patientID'=>$patientID));
	//print_r($query->row_array());
	return $query->row_array();

	   }
	   
	   function update($data){
		   
		  $patientID=$this->input->post('patientID');
	   
	   $this->db->where('patientID',$patientID);
		$this->db->update('patient', $data);
	   
	   }
	
	

	
	function delete($patientID){
	 
	 $this->db->where('patientID',$patientID);
    $this->db->delete('patient');
	
	}
	
	function login($userID, $password)
	 {
	 $query = $this->db->get_where('clinic_user',array ('userID'=>$userID));
	 if($query->num_rows()>0){
		 $query =$query->row_Array();
		 $user_id=$query['userID'];
		 $password_user=$query['password'];
		 
		 if($userID==$user_id){
			 $IDdata= array('user_id'=>$user_id);
			 $this->session->set_userdata($IDdata);
			 
			 $password= $password;
			 
			 if($password != $password_user){
				 return false;
			 }
			 else{
				$IDdata= array('user_id'=>$user_id); 
				$this->session->set_userdata($IDdata);
			 return true;
		 }
		 }
		 else{
			 false;
		 }
	 }
	 }
	 
	
	
	 
	  function get_calendar_data($year,$month){
		
		$cal_data= array();	
		$query= $this->db->select('date,treatment')->from('calendar')->like('date',"$year-$month",'after')->get();
		 $query = $query->result();
		 
		 foreach($query  as $row){
			 $day = (int)substr($row->date,8,2);
			 $cal_data[$day]= $row->treatment;
			 
		 }
		return $cal_data ;
	 }
	 
	 function addAppointment($date,$treatment){
	 
	if($this->db->select('date')->from('calendar')->where('date',$date)->count_all_results()){
		 
		 $this->db->where('date',$date)
		 ->update('calendar',array
		 ('date'=>$date,
		 'treatment'=>$treatment));
	 }
	 
	 else{
		 
		 
		 
	 //$query = $this->db->get_where('calendar',array('date'=>$cal_data['date'])); 
	 
	 
	 
	 /*if($query->num_rows()>0){
	 echo "Adding exist";
	 }else{
		*/
		$this->db->insert('calendar',
		array('date'=>$date,
		'treatment'=>$treatment));
	 
	 
	 }
	 
	 
	 
	 }
	 
	function addnew_d($data){
		$this->db->insert('clinic_user', $data);
		return true;
	}

 function d_update($data){
		   
		  $userID=$this->input->post('userID');
	   
	   $this->db->where('userID',$userID);
		$this->db->update('clinic_user', $data);
	   
	   }
	
	

	
	function d_delete($userID){
	 
	 $this->db->where('userID',$userID);
    $this->db->delete('clinic_user');
	
	}
	
	 function get_appointment(){
	    $this->load->database();
		$query = $this->db->get("appointment");
		if ( $query->num_rows() > 0 ) {
			$output['dbrow'] = $query->result();
		} 
		else {
			$output['dbrow'] = null;
		}
		$query->free_result();
		//print_r($output);
		$this->load->view("o_all_appointment", $output);
	  	return $output['dbrow'];
	   }
	   
	   function getAppointmentByAppointmentId($appointmentID){
		
		 
	$query = $this->db->get_where('appointment',array('appointmentID'=>$appointmentID));
	return $query->row_array();

	   }
	
	function make_new($data){
		$this->db->insert('appointment', $data);
		return true;
	}
	
	function appointment_update($data){
		   
		 $appointmentID=$this->input->post('appointmentID');
	   
	  	$this->db->where('appointmentID',$appointmentID);
		$this->db->update('appointment', $data);
	   
	   }
	 function app_delete($appointmentID){
	 
	 	$this->db->where('appointmentID',$appointmentID);
    	$this->db->delete('appointment');
	
	}
	
	function getAppointmentByID($patientID){
		$this->load->database();
		$query = $this->db->get_where('appointment',array('patientID'=>$patientID));
		if($query->num_rows()>0){
			$output['dbrow'] = $query->result();
			}
		else{
			$output['dbrow'] = null;
			}
		$query->free_result();
		print_r($output);
		$this->load->view("patient_own_schedule", $output);
		return $output['dbrow'];
	   }
	   
	   function getAppointmentByUserID($userID){
		$this->load->database();
		$query = $this->db->get_where('appointment',array('userID'=>$userID));
		if($query->num_rows()>0){
			$output['dbrow'] = $query->result();
			}
		else{
			$output['dbrow'] = null;
			}
		$query->free_result();
		$this->load->view("dentist_own_schedule", $output);
		return $output['dbrow'];

	   }
	   
	   
	   
	function get_p_calendar(){
	    $this->load->database();
		$query = $this->db->get("patient");
		if ( $query->num_rows() > 0 ) {
			$output['dbrow'] = $query->result();
		} else {
			$output['dbrow'] = null;
		}
		$query->free_result();
		$this->load->view("view_p_calendar", $output);
	  
	   }
	function get_d_calendar(){
	    $this->load->database();
		$query = $this->db->get("clinic_user");
		if ( $query->num_rows() > 0 ) {
			$output['dbrow'] = $query->result();
		} else {
			$output['dbrow'] = null;
		}
		$query->free_result();
		$this->load->view("view_d_calendar", $output);
	  
	   }
}

	