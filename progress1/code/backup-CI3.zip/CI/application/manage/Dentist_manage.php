<?php

class Dentist_manage extends CI_Controller{
	
	public function login($userID, $password){
		$this->load->model('Dentist_Model');
		$result=$this->Dentist_Model->login($userID,$password);
		return $result;
		}
	public function getCalendarByUserID($userID){
		$this->load->model('Dentist_Model');
		$data['user']=$this->Dentist_Model->getAppointmentByID($userID);
		return $data['user'];
		}
	}

?>