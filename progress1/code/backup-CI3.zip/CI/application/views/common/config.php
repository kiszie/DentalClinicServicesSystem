<?php
	$server = "192.168.1.251";
	$user	= "scheduler";
	$pass	= "scheduler";
	$db_name= "schedulertest";
?>