-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `dentalclinic`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `appointment`
-- 

CREATE TABLE `appointment` (
  `appointmentID` int(11) NOT NULL auto_increment,
  `patientID` varchar(10) NOT NULL,
  `dentistID` varchar(10) NOT NULL,
  `aDate` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `description` varchar(100) default NULL,
  PRIMARY KEY  (`appointmentID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `appointment`
-- 

INSERT INTO `appointment` VALUES (1, 'test', 'D001', '2014-07-23', '13:00:00', '13:30:00', 'xxxx', 'xxxx');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `calendar`
-- 

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `treatment` text NOT NULL,
  PRIMARY KEY  (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `calendar`
-- 

INSERT INTO `calendar` VALUES ('2014-03-13', 'hahahaha');
INSERT INTO `calendar` VALUES ('2014-03-16', 'Gloyjai');
INSERT INTO `calendar` VALUES ('2014-03-20', 'Hello!!!!!!!!');
INSERT INTO `calendar` VALUES ('2014-03-21', 'Godzilla');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `ci_sessions`
-- 

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `ci_sessions`
-- 

INSERT INTO `ci_sessions` VALUES ('307e275eadb6c0f6790526432de6cc68', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406094321, 'a:1:{s:10:"officer_id";s:5:"admin";}');
INSERT INTO `ci_sessions` VALUES ('d0f721fa993feb78a27745d942485ce2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406089725, 'a:2:{s:9:"user_data";s:0:"";s:10:"officer_id";s:5:"admin";}');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `dentist`
-- 

CREATE TABLE `dentist` (
  `dentistID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  PRIMARY KEY  (`dentistID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `dentist`
-- 

INSERT INTO `dentist` VALUES ('D001', '1234', 'Donald', 'Duck', 'Chaingmai Thailand', 'DD@gmail.com', '0810000000');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `officer`
-- 

CREATE TABLE `officer` (
  `officerID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  PRIMARY KEY  (`officerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `officer`
-- 

INSERT INTO `officer` VALUES ('admin', '1234', 'xxxx', 'xxxx', 'xxxx', 'xxxx@xx.com', '0000000000');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient`
-- 

CREATE TABLE `patient` (
  `patientID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `gender` int(1) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `submit` varchar(10) NOT NULL,
  PRIMARY KEY  (`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `patient`
-- 

INSERT INTO `patient` VALUES ('test', '1234', 'xxxx', 'xxxx', 21, 2, 'xxxx', 'xxxx', '0000000000', 'xxxx@xxx.com', '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient_appointement`
-- 

CREATE TABLE `patient_appointement` (
  `ID` int(11) NOT NULL auto_increment,
  `patientID` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `dentist` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `patient_appointement`
-- 

INSERT INTO `patient_appointement` VALUES (1, 'P1234567', 'Baitarn', 'Baitarn', 'Tooth fairy', '2014-04-09', '00:00:13', 'Miss Bell');
