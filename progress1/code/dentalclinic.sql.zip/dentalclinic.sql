-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `dentalclinic`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient`
-- 

CREATE TABLE `patient` (
  `patientID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `gender` int(1) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `submit` varchar(10) NOT NULL,
  PRIMARY KEY  (`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `patient`
-- 

INSERT INTO `patient` VALUES ('test', '1234', 'xxxx', 'xxxx', 21, 2, 'xxxx', 'xxxx', '0000000000', 'xxxx@xxx.com', '');
