<?php
require_once APPPATH."manage/Dentist_manage.php";
class TestDentist_manage extends CI_controller{
	
	public function testLogin(){
		
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_user_1 = "xxxx";
		$in_pass_1 = "xxxx";
		$expResult1 = false;
		
		$actResult1 = $dentist->login($in_user_1, $in_pass_1);
		echo $this->unit->run($expResult1, $actResult1, "test login -> false case");
		
		$in_user_2 = "test";
		$in_pass_2 = "1234";
		$expResult2 = true;
		
		$actResult2 = $dentist->login($in_user_2, $in_pass_2);
		echo $this->unit->run($expResult2, $actResult2, "test login -> true case");
		}
		
	public function testOwnCalendar(){
		
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_id1 = "xxxx";
		$expResult1 = null;
		
		$actResult1 = $dentist->getCalendarByUserID($in_id1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		
		$in_id2 = "dent001";
		$x2 = $this->load->model('Dentist_Model');
		$x2->appointmentID = 16;
		$x2->patientID = 'P0004';
		$x2->userID = 'dent001';
		$x2->aDate = '2014-07-04';
		$x2->startTime = '14:30:00';
		$x2->endTime = '15:00:00';
		$x2->treatment = 'aaaa';
		$x2->description = 'aaaa';
		//Array ( [0] => stdClass Object ( [appointmentID] => 16 [patientID] => P0004 [userID] => dent001 [aDate] => 2014-07-04 [startTime] => 14:30:00 [endTime] => 15:00:00 [treatment] => aaaa [description] => aaaa ) )
		$expResult2[0] = $x2; 
		$actResult2 = $dentist->getCalendarByUserID($in_id2);
		
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		}
	
	}
?>