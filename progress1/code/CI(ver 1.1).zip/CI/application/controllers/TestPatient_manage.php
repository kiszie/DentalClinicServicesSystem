<?php
require_once APPPATH."manage/Patient_manage.php";
class TestPatient_manage extends CI_Controller
{
	public function testLogin()
	{
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$in_user_1 = "xxxxxx";
		$in_pass_1 = "xxxxxxx";
		$expResult1 = false;
		
		$actResult1 = $patient->login($in_user_1, $in_pass_1);
		echo $this->unit->run($expResult1, $actResult1, "test login -> false case");
		
		$in_user_2 = "P0003";
		$in_pass_2 = "1234";
		$expResult2 = true;
		
		$actResult2 = $patient->login($in_user_2, $in_pass_2);
		echo $this->unit->run($expResult2, $actResult2, "test login -> true case");
	}
	
	public function testOwnCalendar(){
		
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$in_id1 = "xxxx";
		$expResult1 = null; 
		$actResult1 = $patient->getCalendarByPID($in_id1);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id2 = "1";
		//$expResult2 = true;
		//$expResult2 = array('1','1','test','2014-06-08','13:00:00','13:30:00','Bridge','-');
		//Array ( [dbrow] => Array ( [0] => stdClass Object ( [appointmentID] => 1 [patientID] => 1 [userID] => test [aDate] => 2014-06-08 [startTime] => 13:00:00 [endTime] => 13:30:00 [treatment] => Bridge [description] => - ) ) )
		
		$x2 = $this->load->model('Patient_Model');
		$x2->appointmentID = 1;
		$x2->patientID = '1';
		$x2->userID = 'test';
		$x2->aDate = '2014-06-08';
		$x2->startTime = '13:00:00';
		$x2->endTime = '13:30:00';
		$x2->treatment = 'Bridge';
		$x2->description = '-';
		//$expResult2[0] = array("appointmentID"=>1,"patientID"=>'1',"userID"=>'test',"aDate"=>'2014-06-08',"startTime"=>'13:00:00',"endTime"=>'13:30:00',"treatment"=>'Bridge',"description"=>'-');
		$expResult2[0] = $x2; 
		$actResult2 = $patient->getCalendarByPID($in_id2);
		
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		
		}
}
?>