<?php

class Officer_manage extends CI_controller{
	
	public function login($officerID, $password){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->login($officerID,$password);
		return $result;
		}
	public function get_p_db(){
		$this->load->database();
		$this->load->model('Offiecer_Model');
		return $this->Offiecer_Model->get_p_data();
		}
	public function get_db(){
		$this->load->database();
	 	$this->load->model('Offiecer_Model');
  		return $this->Offiecer_Model->get_data();
		}
	public function p_register(){
		$this->load->model('Offiecer_Model');
		//$status = false;
			//if($this->input->post('submit')){
				
				$patientID = $this->input->post('patientID');	
				
				$check = $this->Offiecer_Model->checkDuplicate_p($patientID);
				if($check==false){
					$data = array(
    					'patientID '=> $this->input->post('patientID'),
						'password'=> $this->input->post('password'),
     					'f_name' => $this->input->post('f_name'),
     					'l_name' => $this->input->post('l_name'),
						'age'=>$this->input->post('age'),
						'gender'=>$this->input->post('gender'),
						'treatment'=>$this->input->post('treatment'),
						'address'=>$this->input->post('address'),
						'tel'=>$this->input->post('tel'),
						'email'=>$this->input->post('email'),
						'submit'=>$this->input->post('submit'));
				$result = $this->Offiecer_Model->addnew($data);
				//print_r($check);
				//print_r($data);
				return $result;
				}
				else{
					return false;
					}
		}
		/*public function test($patientID){
			$this->load->model('Offiecer_Model');
			return $this->Offiecer_Model->checkDuplicate($patientID);
			}*/
		
	public function p_edit($patientID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->get_p_DataById($patientID);
		return $data['user'];
		}	
	public function edit_data(){
		
		$data['patientID']=$this->input->post('patientID');
		$data['password']=$this->input->post('password');
		$data['f_name']=$this->input->post('f_name');
		$data['l_name']=$this->input->post('l_name');
		$data['age']=$this->input->post('age');
		$data['gender']=$this->input->post('gender');
		$data['treatment']=$this->input->post('treatment');
		$data['address']=$this->input->post('address');
		$data['tel']=$this->input->post('tel');
		$data['email']=$this->input->post('email');
		$data['submit']=$this->input->post('save');
		
		$this->load->model('Offiecer_Model');
	
		$result = $this->Offiecer_Model->update($data);
		//echo $this->Offiecer_Model->get_p_data();
		return $result;
		}
	public function p_delete($patientID){
		$this->load->model('Offiecer_Model');
  		$result = $this->Offiecer_Model->delete($patientID);
		return $result;
		//echo $this->Offiecer_Model->get_p_data();
		}
	public function d_register(){
		$this->load->model('Offiecer_Model');
		$dentistID = $this->input->post('dentistID');	
		$check = $this->Offiecer_Model->checkDuplicate_d($dentistID);
		if($check==false){
			$data = array(
    			'dentistID '=> $this->input->post('dentistID'),
				'password'=> $this->input->post('password'),
     			'f_name' => $this->input->post('f_name'),
     			'l_name' => $this->input->post('l_name'),
				'address'=>$this->input->post('address'),
				'tel'=>$this->input->post('tel'),
				'email'=>$this->input->post('email'),
				'submit'=>$this->input->post('submit'));
			$result = $this->Offiecer_Model->addnew_d($data);
			return $result;
			}
		else{
			return false;
			}
		}
		
	public function d_edit($dentistID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getDataById($dentistID);
		return $data['user'];
		}
	public function d_edit_data(){
		
		$date['dentistID']=$this->input->post('dentistID');
		$data['password']=$this->input->post('password');
     	$data['f_name']=$this->input->post('f_name');
     	$data['l_name']=$this->input->post('l_name');
		$data['address']=$this->input->post('address');
		$data['tel']=$this->input->post('tel');
		$data['email']=$this->input->post('email');
		
	
		$this->load->model('Offiecer_Model');
		$result = $this->Offiecer_Model->d_update($data);
		return $result;
		}
	public function d_delete($dentistID){
		$this->load->model('Offiecer_Model');
  		$result = $this->Offiecer_Model->d_delete($dentistID);
		//echo $this->Offiecer_Model->get_data();
		return $result;
		}
	public function view_appointment(){
		$this->load->database();
	  	$this->load->model('Offiecer_Model');
  		return $this->Offiecer_Model->get_appointment();
		}
	public function test($dentistID,$aDate,$startTime){
			$this->load->model('Offiecer_Model');
			return $this->Offiecer_Model->checkDuplicate_app($dentistID,$aDate,$startTime);
			}
	public function make_appointment(){
		$this->load->model('Offiecer_Model');
		$dentistID = $this->input->post('dentistID');
		$aDate = $this->input->post('aDate');
    	$startTime = $this->input->post('startTime');	
		$check = $this->Offiecer_Model->checkDuplicate_app($dentistID,$aDate,$startTime);
		if($check==false){
			$data = array(
    			'patientID'=> $this->input->post('patientID'),
				'dentistID'=>$this->input->post('dentistID'),
				'aDate'=> $this->input->post('aDate'),
    			'startTime' => $this->input->post('startTime'),
    			'endTime' => $this->input->post('endTime'),
				'treatment'=>$this->input->post('treatment'),
				'description'=>$this->input->post('description'),
				'submit'=>$this->input->post('submit'));
			
			$result = $this->Offiecer_Model->make_new($data);
				//echo $this->Offiecer_Model->get_appointment();
			return $result;
		}
		else{
			return false;
			}
		}
	public function app_delete($appointmentID){
		$this->load->model('Offiecer_Model');
  		$result = $this->Offiecer_Model->app_delete($appointmentID);
		//echo $this->Offiecer_Model->get_appointment();
		return $result;
		}
	public function app_edit($appointmentID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByAppointmentId($appointmentID);
		return $data['user'];
		}
	public function app_edit_data(){
		$data['appointmentID']=$this->input->post('appointmentID');
		$data['patientID']=$this->input->post('patientID');
		$data['dentistID']=$this->input->post('dentistID');
		$data['aDate']=$this->input->post('aDate');
		$data['startTime']=$this->input->post('startTime');
		$data['endTime']=$this->input->post('endTime');
		$data['treatment']=$this->input->post('treatment');
		$data['description']=$this->input->post('description');
			
		$this->load->model('Offiecer_Model');
		$result = $this->Offiecer_Model->appointment_update($data);
		return $result;
		}
	public function save_appointment($appointmentID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByAppointmentId($appointmentID);
		return $data;
		}
	public function patientCalendar($patientID){
		$this->load->database();
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByID($patientID);
		return $data['user'];
		}
	public function dentistCalendar($dentistID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByDID($dentistID);
		return $data['user'];
		}
	}
?>