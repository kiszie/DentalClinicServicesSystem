-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `dentalclinic`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `appointment`
-- 

CREATE TABLE `appointment` (
  `appointmentID` int(11) NOT NULL auto_increment,
  `patientID` varchar(10) NOT NULL,
  `dentistID` varchar(10) NOT NULL,
  `aDate` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `description` varchar(100) default NULL,
  PRIMARY KEY  (`appointmentID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `appointment`
-- 

INSERT INTO `appointment` VALUES (1, 'test', 'D001', '2014-07-23', '13:00:00', '13:30:00', 'xxxx', 'xxxx');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `calendar`
-- 

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `treatment` text NOT NULL,
  PRIMARY KEY  (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `calendar`
-- 

INSERT INTO `calendar` VALUES ('2014-03-13', 'hahahaha');
INSERT INTO `calendar` VALUES ('2014-03-16', 'Gloyjai');
INSERT INTO `calendar` VALUES ('2014-03-20', 'Hello!!!!!!!!');
INSERT INTO `calendar` VALUES ('2014-03-21', 'Godzilla');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `ci_sessions`
-- 

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `ci_sessions`
-- 

INSERT INTO `ci_sessions` VALUES ('4fca4626bb521d043df2e833957b0833', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406102825, 'a:2:{s:9:"user_data";s:0:"";s:10:"officer_id";s:5:"admin";}');
INSERT INTO `ci_sessions` VALUES ('34aff0eff6032134b9fbcbfd194d70a2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406101475, '');
INSERT INTO `ci_sessions` VALUES ('8db11f2279d269d07d52823741f0b2f3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406101789, 'a:2:{s:9:"user_data";s:0:"";s:10:"officer_id";s:5:"admin";}');
INSERT INTO `ci_sessions` VALUES ('eb3cff276705626db18a08c7d157006f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406102154, '');
INSERT INTO `ci_sessions` VALUES ('d43befe0a7073265308c415aeb21cadc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406097071, 'a:1:{s:10:"officer_id";s:5:"admin";}');
INSERT INTO `ci_sessions` VALUES ('4bf25e0dc3644e666ae0b1361acb56c1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406099034, 'a:1:{s:10:"officer_id";s:5:"admin";}');
INSERT INTO `ci_sessions` VALUES ('b318d953b57c9e18b0cf83f1c5a6a96d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406099999, '');
INSERT INTO `ci_sessions` VALUES ('1385e063c006102c70581afb7f23c47f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406100327, '');
INSERT INTO `ci_sessions` VALUES ('2ec6f77b37bb4ee4fdb328ea7df28f4a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406100830, '');
INSERT INTO `ci_sessions` VALUES ('b319f4f32275f6b3f70c6b98f551d312', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1406101148, '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `dentist`
-- 

CREATE TABLE `dentist` (
  `dentistID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `submit` varchar(10) default NULL,
  PRIMARY KEY  (`dentistID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `dentist`
-- 

INSERT INTO `dentist` VALUES ('D001', '1234', 'Donald', 'Duck', 'Chaingmai Thailand', 'DD@gmail.com', '0810000000', NULL);
INSERT INTO `dentist` VALUES ('xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx@xxx.com', '1111111111', 'Submit');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `officer`
-- 

CREATE TABLE `officer` (
  `officerID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  PRIMARY KEY  (`officerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `officer`
-- 

INSERT INTO `officer` VALUES ('admin', '1234', 'xxxx', 'xxxx', 'xxxx', 'xxxx@xx.com', '0000000000');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient`
-- 

CREATE TABLE `patient` (
  `patientID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `gender` int(1) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `submit` varchar(10) default NULL,
  PRIMARY KEY  (`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `patient`
-- 

INSERT INTO `patient` VALUES ('test', '1234', 'xxxx', 'xxxx', 21, 1, 'xxxx', 'xxxx', '1111111111', 'xxxx@xxx.com', 'Submit');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient_appointement`
-- 

CREATE TABLE `patient_appointement` (
  `ID` int(11) NOT NULL auto_increment,
  `patientID` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `dentist` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `patient_appointement`
-- 

INSERT INTO `patient_appointement` VALUES (1, 'P1234567', 'Baitarn', 'Baitarn', 'Tooth fairy', '2014-04-09', '00:00:13', 'Miss Bell');
