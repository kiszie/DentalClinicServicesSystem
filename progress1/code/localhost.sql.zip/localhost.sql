-- phpMyAdmin SQL Dump
-- version 4.1.9
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: May 14, 2014 at 10:05 AM
-- Server version: 5.5.34
-- PHP Version: 5.5.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dentalclinic`
--
CREATE DATABASE IF NOT EXISTS `dentalclinic` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dentalclinic`;

-- --------------------------------------------------------

--
-- Table structure for table `Patient_Appointement`
--

CREATE TABLE `Patient_Appointement` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `patientID` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `dentist` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Patient_Appointement`
--

INSERT INTO `Patient_Appointement` (`ID`, `patientID`, `firstname`, `surname`, `treatment`, `date`, `time`, `dentist`) VALUES
(1, 'P1234567', 'Baitarn', 'Baitarn', 'Tooth fairy', '2014-04-09', '00:00:13', 'Miss Bell');

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `treatment` text NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`date`, `treatment`) VALUES
('2014-03-13', 'hahahaha'),
('2014-03-16', 'Gloyjai'),
('2014-03-20', 'Hello!!!!!!!!'),
('2014-03-21', 'Godzilla');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('0e45f8f7feb0f73a9d6a6b0d5aa967f4', '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36', 1399994207, '');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patientID` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `Firstname` varchar(100) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `Age` int(2) NOT NULL,
  `Gender` int(2) NOT NULL,
  `Treatment` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`patientID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patientID`, `password`, `Firstname`, `Surname`, `Age`, `Gender`, `Treatment`, `Address`, `Tel`, `Email`) VALUES
('HELLO', 'b59c67bf196a4758191e42f76670ceba', 'YUNRIM', 'PARK', 38, 0, 'DON''T KNOW YET', 'MOO1', '10101010', 'YUNRIM.PARK@GMAIL.COM'),
('P0000001', '827ccb0eea8a706c4c34a16891f84e7b', 'Bug', 'Bunny', 5, 1, 'Carrot!', 'In the hole!', '1234567890', 'bug@g.com'),
('P0000002', '6074c6aa3488f3c2dddff2a7ca821aab', 'Mickey', 'Mouse', 80, 1, 'Hello!!!', 'Disney land', '053201513', 'M@disney.com'),
('P0000006', 'e1f6a14cd07069692017b53a8ae881f6', 'Jennifer', 'Lopez', 40, 2, '11111', '2', '1234567890', 'J@j.com'),
('P0000007', '7e256a5897b995b39f7fc179a294723c', 'Minie', 'Mouse', 80, 2, '1111', '1', '1111', 'min@disney.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
