<?php
 session_start();
 header ('Content-type: text/html; charset=utf-8');

$hostname = "localhost"; //ชื่อโฮสต์
$user = "root"; //ชื่อผู้ใช้
$password = "root"; //รหัสผ่าน
$dbname = "dentalclinic"; //ชื่อฐานข้อมูล
$tblname = "patient"; //ชื่อตาราง 
// เริ่มติดต่อฐานข้อมูล
mysql_connect($hostname, $user, $password) or die("ติดต่อฐานข้อมูลไม่ได้");
// เลือกฐานข้อมูล
mysql_select_db($dbname) or die("เลือกฐานข้อมูลไม่ได้");

// คำสั่ง SQL และสั่งให้ทำงาน
$sql = "select * from $tblname where patientID='$patientID' and password='$password'"; //เช็คค่าข้อมูลที่ส่งมาจากฟอร์ม
$dbquery = mysql_db_query($dbname, $sql);

// หาจำนวนเรกคอร์ดข้อมูล
$num_rows = mysql_num_rows($dbquery);
if($num_rows==1){
header("about.html"); //ไปไปตามหน้าที่คุณต้องการ
}else {
$code_error="<BR><FONT COLOR=\"red\">ข้อมูลที่คุณกรอกไม่ถูกต้อง กรุณา Login ใหม่อีกครั้ง</FONT>";
session_register("code_error");
header("login.html"); //ไม่ถูกต้องให้กับไปหน้าเดิม
}
?>
