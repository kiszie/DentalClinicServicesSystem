<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE HTML>
<html>
<head>
<title>Eracle for Iphone, Android &nbsp; Smartphone Mobile Website Template | About : w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The free Eracle Iphone web template, Andriod web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(
hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.html">
				<img src="images/lg.png" alt=""/>
				<h1>DENTAL</h1>
				<div class="clear"> </div>
			 </a>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
							<li class="active"><a href="index.html">Home</a></li>
							<li class="active"><a href="login.html">Login</a></li>
							<li class="active"><a href="calendar.html">Calendar</a></li>
							<li><a href="pages.html">Pages</a></li>
							<li><a href="blog.html">Blog</a></li>
							<li><a href="contact.html">Contact us</a></li>
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
		<!-----end-header-------->
		<!----start-content--->
			<div class="content_1" align="center">
				<div class="wrap">
					<div class="about">
				<div class="about-top">
				  <div class="col span_1_of_about">
							<h3 class="heading"><strong>Login</strong></h3>
	<div class="section group" >
                            
<form action="check.php" method="post">
  

  <p>
  <label for="patientID">PatientID</label>
        <input type="patientID" name="patientID"/><span class="alert">*</span></p>
    
           
        <p><label for="password">Passsword</label>
        <input type="password" name="password"/><span class="alert">*</span></p>
        <p> <a href="#">Forgotten password?</a></p>
        <p>&nbsp;</p>
       
         
        <p><input type="submit" value="Login" class="continue"/>
</p>
		
    </form>


											
								
			
                    </div>
				  </div>
						<div class="clear"></div> 
					</div>
			  </div>
		</div>
		</div>
				</div>
</body>
</html>