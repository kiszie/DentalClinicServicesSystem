-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 18, 2014 at 06:54 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `dentalclinic`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `appointment`
-- 

CREATE TABLE `appointment` (
  `appointmentID` int(11) NOT NULL auto_increment,
  `patientID` varchar(10) NOT NULL,
  `dentistID` varchar(10) NOT NULL,
  `aDate` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `submit` varchar(10) NOT NULL,
  PRIMARY KEY  (`appointmentID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

-- 
-- Dumping data for table `appointment`
-- 

INSERT INTO `appointment` VALUES (34, 'P007', 'D003', '2014-10-21', '09:00:00', '09:30:00', 'Tooth braces', '-', 'Submit');
INSERT INTO `appointment` VALUES (35, 'P002', 'D001', '2014-10-15', '22:59:00', '23:00:00', 'sss', 'ssss', '');
INSERT INTO `appointment` VALUES (36, 'P001', 'D001', '2014-10-17', '19:00:00', '19:30:00', 'check up', '-', 'Submit');
INSERT INTO `appointment` VALUES (38, 'P002', 'D001', '2014-10-24', '14:12:38', '14:12:38', 'aaaa', 'aaaa', '');
INSERT INTO `appointment` VALUES (39, 'P001', 'D001', '2014-10-28', '14:17:28', '14:17:28', 'aaaa', 'aaaa', '');
INSERT INTO `appointment` VALUES (41, 'P008', 'D002', '2014-10-18', '19:00:00', '19:30:00', 'aaaa', 'aaaa', 'Submit');

-- --------------------------------------------------------

-- 
-- Table structure for table `calendar`
-- 

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `treatment` text NOT NULL,
  PRIMARY KEY  (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `calendar`
-- 

INSERT INTO `calendar` VALUES ('2014-03-13', 'hahahaha');
INSERT INTO `calendar` VALUES ('2014-03-16', 'Gloyjai');
INSERT INTO `calendar` VALUES ('2014-03-20', 'Hello!!!!!!!!');
INSERT INTO `calendar` VALUES ('2014-03-21', 'Godzilla');

-- --------------------------------------------------------

-- 
-- Table structure for table `ci_sessions`
-- 

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `ci_sessions`
-- 

INSERT INTO `ci_sessions` VALUES ('b462cdfcb987e1236731ee663509c787', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36', 1413584734, 'a:1:{s:10:"officer_id";s:5:"OF001";}');
INSERT INTO `ci_sessions` VALUES ('2e4c69d85beee93e91b613bf63b5e851', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36', 1413587676, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `dentist`
-- 

CREATE TABLE `dentist` (
  `dentistID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `submit` varchar(10) default NULL,
  PRIMARY KEY  (`dentistID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `dentist`
-- 

INSERT INTO `dentist` VALUES ('D001', '1234', 'Donald', 'Duck', 'Chaingmai Thailand', 'DD@gmail.com', '0810000000', NULL);
INSERT INTO `dentist` VALUES ('D002', '6789', 'Daisy', 'Duck', 'New York,USA', 'D_lady@hotmail.com', '0810000001', 'Submit');

-- --------------------------------------------------------

-- 
-- Table structure for table `followup`
-- 

CREATE TABLE `followup` (
  `qid` int(11) NOT NULL auto_increment,
  `patientID` varchar(10) NOT NULL,
  `dentistID` varchar(10) default NULL,
  `question` varchar(200) NOT NULL,
  `answer` varchar(200) default NULL,
  `qDateTime` datetime NOT NULL,
  `aDateTime` datetime default NULL,
  PRIMARY KEY  (`qid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `followup`
-- 

INSERT INTO `followup` VALUES (11, 'P001', 'D001', 'What you got!', 'wassup', '2014-09-28 11:04:00', '2014-09-29 05:31:56');
INSERT INTO `followup` VALUES (8, 'P003', 'D001', 'wassup', 'fine thx', '2014-09-28 10:25:35', '2014-09-30 04:56:48');
INSERT INTO `followup` VALUES (9, 'P003', 'D001', 'hell yeahhh', NULL, '2014-09-28 10:26:40', NULL);
INSERT INTO `followup` VALUES (12, 'P001', 'D001', 'How are braces doing', 'fine thx', '2014-10-01 04:01:17', '2014-10-01 04:01:46');

-- --------------------------------------------------------

-- 
-- Table structure for table `information`
-- 

CREATE TABLE `information` (
  `infoID` int(11) NOT NULL auto_increment,
  `type` varchar(5) NOT NULL,
  `title` varchar(50) NOT NULL,
  `details` varchar(400) NOT NULL,
  `officerID` varchar(10) NOT NULL,
  PRIMARY KEY  (`infoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `information`
-- 

INSERT INTO `information` VALUES (1, 'promo', 'Test', 'sth', 'OF001');
INSERT INTO `information` VALUES (2, 'info', 'Test', 'Test', 'OF001');
INSERT INTO `information` VALUES (3, 'promo', 'Testtitle', 'Test', 'OF001');
INSERT INTO `information` VALUES (4, 'promo', 'fffff', 'fffff', 'OF001');

-- --------------------------------------------------------

-- 
-- Table structure for table `officer`
-- 

CREATE TABLE `officer` (
  `officerID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  PRIMARY KEY  (`officerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `officer`
-- 

INSERT INTO `officer` VALUES ('admin', '1234', 'xxxx', 'xxxx', 'xxxx', 'xxxx@xx.com', '0000000000');
INSERT INTO `officer` VALUES ('OF001', '1234', 'Bug', 'Bunny', 'Chaingmai Thailand', 'BB@gmail.com', '0811111111');

-- --------------------------------------------------------

-- 
-- Table structure for table `patient`
-- 

CREATE TABLE `patient` (
  `patientID` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `gender` int(1) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `submit` varchar(10) default NULL,
  PRIMARY KEY  (`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `patient`
-- 

INSERT INTO `patient` VALUES ('P010', '1234', 'Tom', 'Cat', 12, 2, 'Braces', 'Somewhere', '1010101010', 'GG@yahoo.com', 'submit');
INSERT INTO `patient` VALUES ('P001', '1234', 'Mickey', 'Mouse', 80, 1, 'Braces', 'Chaingmai Thailand', '053111111', 'M.ky@hotmail.com', '0');
INSERT INTO `patient` VALUES ('P002', '1111', 'Minnie', 'Mouse', 80, 2, 'zepline', 'New York,USA', '0120000000', 'M.Nie@hotmail.com', '0');
INSERT INTO `patient` VALUES ('P003', '5555', 'Goofy', 'Goof', 4, 1, 'EF line', 'California,USA', '0230000000', 'GG@yahoo.com', '0');
INSERT INTO `patient` VALUES ('P006', '1234', 'John', 'Doe', 22, 1, '-', 'Chiang Mai, Thailand', '0123456548', 'john.d@yahoo.com', '0');
INSERT INTO `patient` VALUES ('P007', '1234', 'aaaa', 'xxxx', 21, 1, '-', 'xxxx', '0123456548', 'xxxx@xxx.com', '0');
INSERT INTO `patient` VALUES ('P008', '1234', 'Alexander', 'Wang', 32, 1, 'check up', 'Chicago, USA', '098765487', 'alex.wang83@yahoo.com', 'Submit');
INSERT INTO `patient` VALUES ('P009', '1234', 'John', 'Doe', 19, 1, 'Retainer', 'California,USA', '1010101010', 'jd@hotmail.com', 'Submit');

-- --------------------------------------------------------

-- 
-- Table structure for table `patient_appointement`
-- 

CREATE TABLE `patient_appointement` (
  `ID` int(11) NOT NULL auto_increment,
  `patientID` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `dentist` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `patient_appointement`
-- 

INSERT INTO `patient_appointement` VALUES (1, 'P1234567', 'Baitarn', 'Baitarn', 'Tooth fairy', '2014-04-09', '00:00:13', 'Miss Bell');

-- --------------------------------------------------------

-- 
-- Table structure for table `queue`
-- 

CREATE TABLE `queue` (
  `qnum` int(11) NOT NULL,
  `patientID` varchar(10) default NULL,
  PRIMARY KEY  (`qnum`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `queue`
-- 

INSERT INTO `queue` VALUES (0, 'pone');
INSERT INTO `queue` VALUES (1, 'p');
INSERT INTO `queue` VALUES (2, 'p2');
INSERT INTO `queue` VALUES (3, 'ptwo');
INSERT INTO `queue` VALUES (4, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `treatment`
-- 

CREATE TABLE `treatment` (
  `tid` int(11) NOT NULL auto_increment,
  `tName` varchar(20) NOT NULL,
  `cost` double NOT NULL,
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- Dumping data for table `treatment`
-- 

INSERT INTO `treatment` VALUES (1, 'Full mouth checkup', 0);
INSERT INTO `treatment` VALUES (2, 'Composite filling', 1000);
INSERT INTO `treatment` VALUES (3, 'Fluoride application', 400);
INSERT INTO `treatment` VALUES (4, 'Consultation', 0);
INSERT INTO `treatment` VALUES (5, 'Extraction', 800);
INSERT INTO `treatment` VALUES (7, 'Root curette', 400);
INSERT INTO `treatment` VALUES (9, 'Intraoral x-ray', 700);
INSERT INTO `treatment` VALUES (10, 'Regular cleaning', 600);
INSERT INTO `treatment` VALUES (11, 'Whitening/Bleaching', 3000);
INSERT INTO `treatment` VALUES (12, 'Braces', 40000);
INSERT INTO `treatment` VALUES (13, 'EF line', 25000);
INSERT INTO `treatment` VALUES (14, 'Retainer', 4000);
