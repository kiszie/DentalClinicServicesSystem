<? session_start(); ?>
  <?php

  

// header("access-control-allow-origin: *") ;
  

            /*$link = mysql_connect("localhost", "root","root") or die("Could not connect to host.");
            mysql_select_db("dentalclinic", $link) or die("Could not find database.");*/
			
//$dbhost = "10.73.15.228"; 
//$dbuser = "nui"; 
//$dbpass = "1234";
//$dbhost = "localhost"; 
$dbhost = "localhost";
$dbuser = "root"; 
$dbpass = "1234";  
$dbname = "dentalclinic"; 
//header("Location: http://www.google.co.th");

$con = mysql_connect($dbhost, $dbuser, $dbpass) or die("Could not connect to the database"); 

mysql_select_db($dbname,$con) or die("Could not select with databse"); 

            $pid = $_POST['pid'];
            $password = $_POST['password'];



            $sql = "select * from patient where patientID='$pid' and password='$password'";
           
$result=mysql_query($sql) or die(mysql_error());
$num_row = mysql_num_rows($result);
$row=mysql_fetch_array($result);


            if ($num_row >=1) {
				
			$_SESSION['ses_userid'] = session_id();
			$_SESSION['ses_user'] = $pid; 
			
           $response['success'] = true;
		  
		  
		 	
            }
            else
            {
            $response['success'] = false;
			
            }

            echo json_encode($response);
			  

             //echo 'OK';
			session_write_close();
            ?>
