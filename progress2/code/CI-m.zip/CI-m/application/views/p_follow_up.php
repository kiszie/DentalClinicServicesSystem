<!DOCTYPE HTML>
<html>
<head>
<title>Eracle for Iphone, Android &nbsp; Smartphone Mobile Website Template | Home : w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The free Eracle Iphone web template, Andriod web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(
hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="http://localhost/CI-m/assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://localhost/CI-m/assets/css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="http://localhost/CI-m/assets/css/magnific-popup.css" />
<script type="text/javascript" src="http://localhost/CI-m/assets/js/jquery.min.js"></script>
<script src="http://localhost/CI-m/assets/js/owl.carousel.js"></script>
	<script>
			$(document).ready(function() {
				$("#owl-demo").owlCarousel({
					items : 4,
					lazyLoad : true,
					autoPlay : true,
					navigation : true,
					navigationText : ["", ""],
					rewindNav : false,
					scrollPerPage : false,
					pagination : false,
					paginationNumbers : false,
				});
			});
		</script>
		<!-- //Owl Carousel Assets -->
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="http://localhost/CI-m/assets/css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="http://localhost/CI-m/assets/js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="http://localhost/CI-m/index.html">
				<img src="http://localhost/CI-m/images/lg.png" alt=""/>
			<h1>DENTAL</h1>
				<div class="clear"> </div>
                
		  </a>
		</div>
		<div class="clear"> </div>
       
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
                          <li class="active"><a href="http://localhost/CI-m/index.html">Home</a></li>
                          <li class="active"><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/loginMobile">Login</a></li>
                          <li class="active"><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/callCalendar">Calendar</a></li>
                          <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/patientAppointment/<?php echo $PID ?>">Appointment</a></li>
                          <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/view_follow_up/<?php echo $PID ?>">Follow up</a></li>
                          <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/p_detail/<?php echo $PID ?>">Your QR</a></li>
                          <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/callTreatment/">Dental Treatment</a></li>
                          <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/logoutMobile">Logout</a></li>
                          <li><a>
                            <?php
                            
                            if($PID != null){
                            echo "<h1><a href='http://localhost/CI-m/index.php/PatientMobile_Controller/patientAppointment/$PID'>$PID</a>  :   <a href='http://localhost/CI-m/index.php/PatientMobile_Controller/logoutMobile/'>LOGOUT</a></h1>";
                            }
                            else{
                            echo "login";
                            }
                            
                            ?>
                          </a> </li>
                          <li class="active"></li>
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
<!--<article>
	<a href="search.html"></a>
</article>-->


<article id="frame">

<table border=5 width="300" bordercolor="#EC1C74">

<tr>
<th>QuestionID</th>
<th>Dentist</th>
<th>Post time</th>
<th>Answer</th>
<tr>
<?php if ( isset($user) && is_array($user) ): ?>

<?php foreach ( $user as $key ): ?>
<?php if($key->patientID==$PID):?>
<td><?php echo $key->qid?></td> 
<td><?php echo $key->dentistID?></td>  
<td><?php echo $key->qDateTime?></td>
<?php if($key->answer==null):?>
<td><a href="<?php echo base_url();?>index.php/PatientMobile_Controller/answer_follow_up/<?php echo $key->qid;?>"/>Answer</a></td>
<?php endif; ?>
<?php if($key->answer!=null): ?>
<td>Answered</td>
<?php endif; ?>
<?php endif; ?>
</tr>
<?php endforeach; ?>

<?php else: ?>
No data
<?php endif; ?>


</table>
</article>	

<!--<footer>
	<div class="wrapper">
    	<span class="logo">ABC comp</span>
        <a href="http://www.webdezign.co.uk" target="_blank" title="web design london" class="right">Web design london</a>&copy; ABC comp <a href="#">Sitemap</a> <a href="#">Terms &amp; Conditions</a> <a href="#">Shipping &amp; Returns</a> <a href="#">Size Guide</a><a href="#">Help</a> <br />
        Address to said ABC comp, including postcode &nbsp;-&nbsp; 1.888.CO.name <a href="mailto:ABC comp">service@ABC comp.com</a>
  </div>
</footer>-->
</body>

</html>
