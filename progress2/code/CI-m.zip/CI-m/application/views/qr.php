<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Eracle for Iphone, Android &nbsp; Smartphone Mobile Website Template | Home : w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The free Eracle Iphone web template, Andriod web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(
hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="http://localhost/CI-m/assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://localhost/CI-m/assets/css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="http://localhost/CI-m/assets/css/magnific-popup.css" />
<script type="text/javascript" src="http://localhost/CI-m/assets/js/jquery.min.js"></script>
<script src="http://localhost/CI-m/assets/js/owl.carousel.js"></script>
	<script>
			$(document).ready(function() {
				$("#owl-demo").owlCarousel({
					items : 4,
					lazyLoad : true,
					autoPlay : true,
					navigation : true,
					navigationText : ["", ""],
					rewindNav : false,
					scrollPerPage : false,
					pagination : false,
					paginationNumbers : false,
				});
			});
		</script>
		<!-- //Owl Carousel Assets -->
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="http://localhost/CI-m/assets/css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="http://localhost/CI-m/assets/js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="http://localhost/CI-m/index.html">
				<img src="http://localhost/CI-m/images/lg.png" alt=""/>
			<h1>DENTAL</h1>
				<div class="clear"> </div>
                
		  </a>
		</div>
		<div class="clear"> </div>
       
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
     <li class="active"><a href="http://localhost/CI-m/index.html">Home</a></li>
	<li class="active"><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/loginMobile">Login</a></li>
		<li class="active"><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/callCalendar">Calendar</a></li>
							<li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/patientAppointment/<?php echo $user['patientID']; ?>">Appointment</a></li>
							<li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/view_follow_up/<?php echo $user['patientID']; ?>">Follow up</a></li>
                            <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/p_detail/<?php echo $user['patientID']; ?>">Your QR</a></li>
                            <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/callTreatment/">Dental Treatment</a></li>
                            <li><a href="http://localhost/CI-m/index.php/PatientMobile_Controller/logoutMobile">Logout</a></li>
							
                            <li><a>
                            <?php
                            
                            if($PID != null){
                            echo "<h1><a href='http://localhost/CI-m/index.php/PatientMobile_Controller/patientAppointment/$PID'>$PID</a>  :   <a href='http://localhost/CI-m/index.php/PatientMobile_Controller/logoutMobile/'>LOGOUT</a></h1>";
                            }
                            else{
                            echo "login";
                            }
                            
                            ?>
                            
                            </a>
                            </li>
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
	<!----//End-image-slider---->
					
						<div class="wrap">
							<form>
<p></p>
<p></p>
<h1>Patients' Details</h1>
    <p></p>
    <h2><?php echo $user['patientID']; ?></h2>
    <p></p>
    <p><b>First name:</b> <?php echo $user['f_name'];?></p>
    <p><b>Last name:</b> <?php echo $user['l_name'];?></p>
    <p><b>Age:</b> <?php echo $user['age'];?></p>
    <p><b>Gender:</b> <?php echo $user['gender'];?></p>
    <p><b>Address:</b> <?php echo $user['address'];?></p>
    <p><b>Email:</b> <?php echo $user['email'];?></p>
    <p><b>Tel:</b> <?php echo $user['tel'];?></p>
<?php 
echo '<img src="'.base_url().'test.png" />'
 ?>
 </form>
						</div>
					</div>