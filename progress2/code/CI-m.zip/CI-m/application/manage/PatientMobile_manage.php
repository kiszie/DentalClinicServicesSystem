<?php

class PatientMobile_manage extends CI_Controller{
	
	public function loginMobile($patientID, $password){
		$this->load->model('PatientMobile_Model');
		$result=$this->PatientMobile_Model->loginMobile($patientID,$password);
		return $result;
		}
	
	public function getCalendarByPID($patientID){
		$this->load->model('PatientMobile_Model');
		$data['user']=$this->PatientMobile_Model->getAppointmentByID($patientID);
		//print_r($data);
		return $data['user'];
		}
		public function getAllTreat(){
		$this->load->database();
		$this->load->model('PatientMobile_Model');
		return $this->PatientMobile_Model->retrieve_treatment();
		}
	public function getTreatmentByID($t_id){
		$this->load->model('PatientMobile_Model');
		$data['treatment'] = $this->PatientMobile_Model->get_treat($t_id);
		return $data['treatment'];
		}
	public function cost_est_treat($dent_treat){
		$result=0;
		foreach($dent_treat['cost'] as $value){
			$result += $value;
			}
		//echo "value="+$value;
		//print_r("value="+$result);
		return $result;
		}
	public function view_follow_up(){
		$this->load->database();
		$this->load->model('PatientMobile_Model');
		return $this->PatientMobile_Model->get_follow_up();
		}
	public function viewFollowUpByQid($qid){
		$this->load->database();
		$this->load->model('PatientMobile_Model');
		$data['user'] = $this->PatientMobile_Model->getFollowUpByQid($qid);
		return $data['user'];
		}
	public function answer_data($data){
		$this->load->database();
		$this->load->model('PatientMobile_Model');
		$result = $this->PatientMobile_Model->save_answer($data);
		return $result;
		}
		}
		

	
	
	
?>