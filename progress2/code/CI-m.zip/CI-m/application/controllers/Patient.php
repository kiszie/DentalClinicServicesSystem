<?php if(!defined('BASEPATH'))
 exit('no direct script access allowed');

class Patient extends CI_Controller{
	public function index(){
		if($this->session->userdata('patient_id')){
			$data['PID']=$this->session->userdata('patient_id');
			$this->load->view('index.html',$data);
			}
		else{
			redirect('http://localhost/CI-m/index.php/PatientMobile_Controller/loginMobile');
			}
		}
		function cost_est(){
		$patient = new Patient_manage();
		//$this->load->view('d_cost_est');
		$treatment = array(
			't1' => $this->input->post('checkup'),
			't2' => $this->input->post('compositeFill'),
			't3' => $this->input->post('fluoride'),
			't4' => $this->input->post('consult'),
			't5' => $this->input->post('extraction'),
			't6' => $this->input->post('rootCurette'),
			't7' => $this->input->post('xray'),
			't8' => $this->input->post('regularClean'),
			't9' => $this->input->post('whitening')
		);
		print_r($treatment);
		$result = $pentient->calculate($treatment);
			/*$t1 = $this->input->post('checkup');
			$t2 = $this->input->post('compositeFill');
			$t3 = $this->input->post('fluoride');
			$t4 = $this->input->post('consult');
			$t5 = $this->input->post('extraction');
			$t6 = $this->input->post('rootCurette');
			$t7 = $this->input->post('xray');
			$t8 = $this->input->post('regularClean');
			$t9 = $this->input->post('whitening');
			$result = $t1+$t2+$t3+$t4+$t5+$t6+$t7+$t8+$t9;
*/			
			print_r($result);
			$data['result']=$result;
			$this->load->view('d_cost_est',$data);
			
			
			$result = 0;
		}
	}
?>