<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script type="text/javascript" src="http://js.addthisevent.com/atemay.js"></script>
<script type="text/javascript">
addthisevent.settings({
    license   : "aao8iuet5zp9iqw5sm9z",
    mouse     : false,
    css       : true,
    outlook   : {show:true, text:"Outlook Calendar"},
    google    : {show:true, text:"Google Calendar"},
    yahoo     : {show:true, text:"Yahoo Calendar"},
    hotmail   : {show:true, text:"Hotmail Calendar"},
    ical      : {show:true, text:"iCal Calendar"},
    facebook  : {show:true, text:"Facebook Event"},
    dropdown  : {order:"outlook,google,ical"},
    callback  : ""
});
</script>
</head>

<body>
<a href="http://example.com/link-to-your-event" title="Add to Calendar" class="addthisevent">
    Add to Calendar
    <span class="_start">11-06-2014 13:30:46</span>
    <span class="_end">11-06-2014 14:30:46</span>
    <span class="_zonecode">75</span>
    <span class="_summary">P001</span>
    <span class="_description">Dent01</span>
    <span class="_location">dantalclinic</span>
    <span class="_organizer">Organizer</span>
    <span class="_organizer_email">Organizer e-mail</span>
    <span class="_facebook_event">http://www.facebook.com/events/160427380695693</span>
    <span class="_all_day_event">false</span>
    <span class="_date_format">DD/MM/YYYY</span>
</a>
</body>
</html>