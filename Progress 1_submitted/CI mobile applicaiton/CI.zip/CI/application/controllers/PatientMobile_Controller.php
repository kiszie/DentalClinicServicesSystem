<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once APPPATH."manage/PatientMobile_manage.php";
class PatientMobile_Controller extends CI_Controller{
	
	function _construct(){
		parent ::construct();
		$this->jquery->script(base_url.'js/jquery.js',TRUE);
		}
		
	public function get_p_db(){
		$this->load->database();
		$this->load->model('PatientMobile_Model');
		echo $this->PatientMobile_Model->get_p_data();
		}
	
		function loginMobile(){
		
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->form_validation->set_rules('patient_id', 'PatientID', 'strip_tags|trim|required|xss_clean');

   $this->form_validation->set_rules('password', 'Password', 'required');
   
   	if($this->form_validation->run()== false){
		$this->load->view('Mobile_login');
	}
	else{
		$patientID = $this->input->post('patient_id');
		$password = $this->input->post('password');
		
		$patient = new PatientMobile_manage();
		$result = $patient->loginMobile($patientID, $password);
	//$this->load->model('Patient_Model');
	//$result=$this->Patient_Model->login($patientID,$password);
	
	if($result == true){
		
		redirect('http://10.73.15.152/CI/index.php/Patient');
	}
	else
	{
        
		$data['error_message'] ="Invalid patientID or password";
		$this->load->view('Mobile_login',$data);
		
		}
		
		}
	
		
		}
	function logoutMobile(){
		
			 $this->session->sess_destroy();
			 
			 redirect('http://10.73.15.152/CI/index.html');
			 
		} 
		
		function callCalendar(){
			$data['PID']=$this->session->userdata('patient_id');
			if(strlen($data['PID'])==0){
				$this->load->view('Mobile_calendar');
				}
			else{
				
				$this->load->view('Mobile_calendar',$data);
				}
			
			
			
			}
	function patientAppointment($patientID){
		$data2['PID']=$this->session->userdata('patient_id');
		if(strlen($data2['PID'])==0){
			$this->load->view('Mobile_appointment');
			}
		else{
			$patient = new PatientMobile_manage();
			$data['user']=$patient->getCalendarByPID($patientID);
			//print_r($data);
			//print_r($data2);
			$this->load->view('Mobile_appointment',$data,$data2);
			//$this->load->model('Patient_Model');
			//$data['user']=$this->Patient_Model->getAppointmentByID($patientID,$data2);
		}
	}
	}

?>