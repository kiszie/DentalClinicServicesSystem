<?php

class PatientMobile_manage extends CI_Controller{
	
	public function loginMobile($patientID, $password){
		$this->load->model('PatientMobile_Model');
		$result=$this->PatientMobile_Model->loginMobile($patientID,$password);
		return $result;
		}
	
	public function getCalendarByPID($patientID){
		$this->load->model('PatientMobile_Model');
		$data['user']=$this->PatientMobile_Model->getAppointmentByID($patientID);
		//print_r($data);
		return $data['user'];
		}
	}
	
	
?>