<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>

<html>

<head>

<title>Eracle for Iphone, Android &nbsp; Smartphone Mobile Website Template | About : w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The free Eracle Iphone web template, Andriod web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(
hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="http://10.73.15.152/CI/assets/css/style1.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="http://10.73.15.152/CI/assets/css/magnific-popup.css">
<script type="text/javascript" src="http://10.73.15.152/CI/js/jquery.min.js"></script>
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="http://10.73.15.152/CI/assets/css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="http://10.73.15.152/CI/assets/js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
        
   
 <script type="text/javascript">
 function Redirect()
{
    window.location="http://www.google.co.th";
}
function handleLogin(username,password) {
 alert("Username "+username+" "+password);
//var form = $("#loginform");    
//disable the button so we can't resubmit while we wait
//$("#submitButton",form).attr("disabled","disabled");
/*var e = $("#pid", input).val();
var p = $("#password", input).val();*/
var e = username;
var p = password;
if(e != "" && p != "") { 
    //var str = form.serialize();
    //alert(str);
    $.ajax({type: 'POST',
			//url: 'http://192.168.1.4/login1.php', //url: 'login1.php',
			//url:'http://192.168.100.51/login1.php',
//url:'http://10.73.12.229/login1.php',

		  url: 'http://localhost/dent17/check.php',
			
                     crossDomain: true,
                     data:  {pid: e, password :p},
                     dataType: 'json', 
                     async: false,

         success: function (response){ 
         //alert("Hahahaah"+response.success);
               if (response.success) { 
         alert("you're logged in");
		  
		 window.localStorage["pid"] = e;
		 window.localStorage["password"] = p; 
     
	  window.location.href="home.php";
	// window.location.href="http://10.73.12.229/index.html";
                        } 
                 else {

            alert("Your login failed ");
			
			 window.location.href="login.html";
			//window.location.href="http://10.73.12.229/login.html";
                           
                        }
						//window.location.assign(response.success);


                     },
                     error: function(error){
                         
alert('Could not connect to the database 555'+error);

        }
    }); 
}
else {
    //if the email and password is empty
    alert("You must enter pid and password");
	  
}
return false;
}
 
 
//www.ondeweb.in/ajax-login-form-with-jquery-and-php/#ixzz33otjn4HT
 </script>


<link rel="stylesheet" href="css/style.css"/>
<body>




		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="http://10.73.15.152/CI/index.html">
				<img src="http://10.73.15.152/CI/images/lg.png" alt=""/>
				<h1>DENTAL</h1>
				<div class="clear"> </div>
			 </a>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
							<li class="active"><a href="http://10.73.15.152/CI/index.html">Home</a></li>
							<li class="active"><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/loginMobile">Login</a></li>
							<li class="active"><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/callCalendar">Calendar</a></li>
							<li><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/patientAppointment">Appointment</a></li>
							<li><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/logoutMobile">Logout</a></li>
					
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
		<!-----end-header-------->
		<!----start-content--->
			<div class="content_1" align="center">
				<div class="wrap">
					<div class="about">
				<div class="about-top">
				  <div class="col span_1_of_about">
							<h3 class="heading"><strong>Login</strong></h3>
	<div class="section group" >

                
<!--<form id="loginform" name="loginform" method="post" >
  
-->
  <!--<p>
  <label for="patientID">PatientID</label>
    <input type="text" name="pid" id="pid" placeholder="PatientID" value="P001" />
    
           
        <p><label for="password">Passsword</label>
        <input type="password" name="password" id="password" placeholder="Password" value="1234"/>
        
        <p> <a href="#">Forgotten password?</a></p>
        <p>&nbsp;</p>
       
         
        <p><input type="button" name="button" id="button" value="Login" class="continue" onClick="handleLogin(document.getElementById('pid').value,document.getElementById('password').value);"/>
</p>-->
<article id="login">
	<form id="form1" name="form1" method="post" action="http://10.73.15.152/CI/index.php/PatientMobile_Controller/loginMobile">
    	
     
    	
        
     <?php 
	 if (!empty($error_message)){
		 echo'<span style="color:red">'.$error_message.'</span>';
	 }?>
        <p><label for="patientID">PatientID</label>
        <input type="patientID" name="patient_id" value="P001" required><span class="alert">*</span></p>
      
        <p><label for="password">Password</label>
        <input type="password" name="password" value="1234" required><span class="alert">*</span></p>
        <p> <a href="#">Forgotten password?</a></p>
        
        <p><input type="submit" value="Login"/></p>
		
    </form>
</article>

						
		
    <!--</form> -->
    
    
      
 
			
								
			
                    </div>
   </div>
						 
					</div>
			  </div>
		</div>
     
		</div>
				</div>
             
				
                <div name="page" id ="page2">
                	<div id="output">
                    
                    
                    </div>
                </div>
        <script type="text/javascript">
 function validationcheck(){

	 if (document.mylogin.patientID.value == "") {
			alert("Please Enter ID.");
			document.mylogin.patientID.focus(); 
		} else if (document.mylogin.password.value == "") {
			alert("Please Enter Password.");
			document.mylogin.password.focus();
		}
		else
			{
		
			  success();
			}
	}
	
	
		
 
</script>
    


</body>
</html>