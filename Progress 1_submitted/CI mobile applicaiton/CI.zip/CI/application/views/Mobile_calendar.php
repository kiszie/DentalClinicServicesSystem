<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Eracle for Iphone, Android &nbsp; Smartphone Mobile Website Template | Pages : w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The free Eracle Iphone web template, Andriod web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(
hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>

<link href="http://10.73.15.152/CI/assets/css/style.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" type="text/css" href="http://10.73.15.152/CI/assets/css/magnific-popup.css">

<script type="text/javascript" src="http://10.73.15.152/CI/assets/js/jquery.min.js"></script>
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="http://10.73.15.152/CI/assets/css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="http://10.73.15.152/CI/assets/js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="http://10.73.15.152/CI/index.html">
				<img src="http://10.73.15.152/CI/assets/images/lg.png" alt=""/>
				<h1>DENTAL</h1>
				<div class="clear"> </div>
			 </a>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					
						<nav id="menu-left">
						<ul>
     <li class="active"><a href="http://10.73.15.152/CI/index.html">Home</a></li>
	<li class="active"><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/loginMobile">Login</a></li>
   <li class="active"><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/callCalendar">Calendar</a></li>
							<li><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/patientAppointment/<?php echo $PID ?>">Appointment</a></li>
							<li><a href="http://10.73.15.152/CI/index.php/PatientMobile_Controller/logoutMobile">Logout</a></li>
<li><a>
<?php
    
    if($PID != null){
        echo "<h1><a href='http://10.73.15.152/CI/index.php/PatientMobile_Controller/patientAppointment/$PID'>$PID</a>  :   <a href='http://10.73.15.152/CI/index.php/PatientMobile_Controller/logoutMobile/'>LOGOUT</a></h1>";
    }
    else{
        echo "login";
    }
    
    ?>

</a>
</li>

						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
<!--------start-blog----------->
<div class="blog">
	<div class="main">
		  	<div class="wrap">
			 	<div class="single-top">
				 <div class="wrapper_single">
					  <div class="wrapper_top">
					 	<div class="content span_2_of_single">
						   		<h3 class="heading">Calendar</h3>
  <div class="l-grids">
	 <div class="l-grid-1">
		<div class="desc">
		 
      <iframe src="https://www.google.com/calendar/embed?title=Dental%20Clinic&amp;showPrint=0&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=dentalclinic.services%40gmail.com&amp;color=%232952A3&amp;ctz=Asia%2FBangkok" style=" border-width:0 " width="300" height="300" frameborder="0" scrolling="no"></iframe>  
      
          </div>
          </div>
          </div>
						
									
                                    
                   <div class="clear"> </div>
								</div>
						   		<h6 class="text">&nbsp;</h6>
					 	</div>
					  </div>
				 </div>
				 <div class="rsidebar span_1_of_3">
				   <div class="tags">
				     </div>
		</div>
				<div class="clear"> </div>
			</div>
		</div>
	</div>
</div>
	<!--------//end-blog_inner----------->
<div class="footer">
				<div class="wrap">
					<div class="footer-left">
						<h3>About eracle</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
						<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
					<div class="detail">
						<ul>
							<li><a href="#">home/</a></li>
							<li><a href="#">term of services/</a></li>
							<li><a href="#">license/</a></li>
							<li><a href="#">pess</a></li>
							<div class="clear"> </div>	
						</ul>
					</div>
					<div class="soc_icons soc_icons1">
							<ul>
								<li><a class="icon1" href="#"> </a> </li>
								<li><a class="icon2" href="#"> </a></li>
								<li><a class="icon3" href="#"> </a></li>
								<div class="clear"> </div>	
							</ul>
								
					</div>
					</div>
					<div class="footer-right">
						<h3>twitter</h3>
						<div class="comments1">
							<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
							<span>~12 hours ago</span>
						</div>
						<div class="comments1">
							<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
							<span>~2 days ago</span>
						</div>
					</div>
					<div class="clear"> </div>	
				</div>
			</div>
			<div class="copy">
				       <p>© 2014 Template by <a href="http://w3layouts.com" target="_blank">w3layouts</a></p>
			  </div>
</body>
</html>