-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `dentalclinic`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `appointment`
-- 

CREATE TABLE `appointment` (
  `appointmentID` int(11) NOT NULL auto_increment,
  `patientID` varchar(10) NOT NULL,
  `dentistID` varchar(10) NOT NULL,
  `aDate` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `submit` varchar(10) NOT NULL,
  PRIMARY KEY  (`appointmentID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

-- 
-- dump ตาราง `appointment`
-- 

INSERT INTO `appointment` VALUES (34, 'P007', 'D003', '2014-10-21', '09:00:00', '09:30:00', 'Tooth braces', '-', 'Submit');
INSERT INTO `appointment` VALUES (1, 'P008', 'D001', '2014-10-28', '19:00:00', '19:30:00', 'aaaa', 'aaaa', '0');
INSERT INTO `appointment` VALUES (36, 'P001', 'D001', '2014-10-29', '19:00:00', '19:30:00', 'check up', '-', 'Submit');
INSERT INTO `appointment` VALUES (38, 'P002', 'D001', '2014-10-24', '14:12:38', '14:12:38', 'aaaa', 'aaaa', '');
INSERT INTO `appointment` VALUES (42, 'P001', 'D001', '2014-11-14', '09:00:00', '09:00:00', 'fffffff', 'hhhh', 'Submit');
INSERT INTO `appointment` VALUES (41, 'P004', 'D002', '2014-10-29', '01:00:00', '01:30:00', 'ssss', 'aaaa', 'Submit');
INSERT INTO `appointment` VALUES (43, 'P001', 'D001', '2014-11-14', '09:00:00', '09:00:00', 'fff', '', 'Submit');
INSERT INTO `appointment` VALUES (44, 'P008', 'D002', '2014-11-19', '09:00:00', '09:30:00', 'Root Canel', '1000 baht', 'Submit');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `calendar`
-- 

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `treatment` text NOT NULL,
  PRIMARY KEY  (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `calendar`
-- 

INSERT INTO `calendar` VALUES ('2014-03-13', 'hahahaha');
INSERT INTO `calendar` VALUES ('2014-03-16', 'Gloyjai');
INSERT INTO `calendar` VALUES ('2014-03-20', 'Hello!!!!!!!!');
INSERT INTO `calendar` VALUES ('2014-03-21', 'Godzilla');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `ci_sessions`
-- 

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `ci_sessions`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `dentist`
-- 

CREATE TABLE `dentist` (
  `dentistID` varchar(10) NOT NULL,
  `password` varchar(32) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `submit` varchar(10) default NULL,
  PRIMARY KEY  (`dentistID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `dentist`
-- 

INSERT INTO `dentist` VALUES ('D001', '81dc9bdb52d04dc20036dbd8313ed055', 'Donald', 'Duck', 'Chaingmai Thailand', 'DD@gmail.com', '0810000000', NULL);
INSERT INTO `dentist` VALUES ('D002', '674f3c2c1a8a6f90461e8a66fb5550ba', 'Daisy', 'Duck', 'New York,USA', 'D_lady@hotmail.com', '0810000001', 'Submit');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `followup`
-- 

CREATE TABLE `followup` (
  `qid` int(11) NOT NULL auto_increment,
  `patientID` varchar(10) NOT NULL,
  `dentistID` varchar(10) default NULL,
  `question` varchar(200) NOT NULL,
  `answer` varchar(200) default NULL,
  `qDateTime` datetime NOT NULL,
  `aDateTime` datetime default NULL,
  PRIMARY KEY  (`qid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

-- 
-- dump ตาราง `followup`
-- 

INSERT INTO `followup` VALUES (14, 'P001', 'D001', 'How are your composite filling? Is that fine?', 'sdsdffdsdf', '2014-10-19 11:04:35', '2014-11-14 04:36:01');
INSERT INTO `followup` VALUES (13, 'P002', 'D002', 'Your retainer is ready in next 3 days (2014-10-15) please come an pick it up at the clinic anytime', 'Ok, thank you very much', '2014-10-12 09:15:22', '2014-10-13 08:00:28');
INSERT INTO `followup` VALUES (9, 'P003', 'D001', 'How is your braces doing?', NULL, '2014-09-28 10:26:40', NULL);
INSERT INTO `followup` VALUES (12, 'P001', 'D001', 'How are braces doing', 'fine thx', '2014-10-01 04:01:17', '2014-10-01 04:01:46');
INSERT INTO `followup` VALUES (30, 'P012', 'D001', 'You forget to check up your braces.', NULL, '2014-11-18 10:20:18', NULL);
INSERT INTO `followup` VALUES (29, 'P012', 'D001', 'How are your composite filling? Is that fine?jkgkgjhggfghffhfghfhfhfh', NULL, '2014-11-14 04:42:33', NULL);
INSERT INTO `followup` VALUES (28, 'P001', 'D001', 'Check up your braces every month please.', NULL, '2014-10-29 01:48:30', NULL);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `information`
-- 

CREATE TABLE `information` (
  `infoID` int(11) NOT NULL auto_increment,
  `type` varchar(5) NOT NULL,
  `title` varchar(50) NOT NULL,
  `details` varchar(400) NOT NULL,
  `officerID` varchar(10) NOT NULL,
  PRIMARY KEY  (`infoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- dump ตาราง `information`
-- 

INSERT INTO `information` VALUES (1, 'promo', 'Free checkup', 'Full mouth checkup for free at the clinic', 'OF001');
INSERT INTO `information` VALUES (2, 'info', 'EF Line', 'EF Line is tooth braces for children between 4-15 years old', 'OF001');
INSERT INTO `information` VALUES (14, 'info', 'Information for ShowPro6.0 event', '19/11/2014', 'OF001');
INSERT INTO `information` VALUES (13, 'info', 'Regular cleaning is now bargain!!!', 'Regular cleaning is now bargain from 600 to 400 baht, until 12/12/2014', 'OF001');
INSERT INTO `information` VALUES (3, 'promo', 'Whitening 30% off', 'End of the year sale, whitening treatment is noe 30% off', 'OF002');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `officer`
-- 

CREATE TABLE `officer` (
  `officerID` varchar(10) NOT NULL,
  `password` varchar(32) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(10) NOT NULL,
  PRIMARY KEY  (`officerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `officer`
-- 

INSERT INTO `officer` VALUES ('admin', '81dc9bdb52d04dc20036dbd8313ed055', 'xxxx', 'xxxx', 'xxxx', 'xxxx@xx.com', '0000000000');
INSERT INTO `officer` VALUES ('OF001', '81dc9bdb52d04dc20036dbd8313ed055', 'Bug', 'Bunny', 'Chaingmai Thailand', 'BB@gmail.com', '0811111111');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient`
-- 

CREATE TABLE `patient` (
  `patientID` varchar(10) NOT NULL,
  `password` varchar(32) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `gender` int(1) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `submit` varchar(10) default NULL,
  PRIMARY KEY  (`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `patient`
-- 

INSERT INTO `patient` VALUES ('P001', '81dc9bdb52d04dc20036dbd8313ed055', 'Mickey', 'Mouse', 80, 1, 'Root curette', 'Chiang Mai, Thailand', '0120000001', 'M.ky@hotmail.com', '0');
INSERT INTO `patient` VALUES ('P002', 'b59c67bf196a4758191e42f76670ceba', 'Minnie', 'Mouse', 80, 2, 'zepline', 'New York,USA', '0120000000', 'M.Nie@hotmail.com', '0');
INSERT INTO `patient` VALUES ('P003', '6074c6aa3488f3c2dddff2a7ca821aab', 'Goofy', 'Goof', 4, 1, 'EF line', 'California,USA', '0230000000', 'GG@yahoo.com', '0');
INSERT INTO `patient` VALUES ('P011', '86a1fa88adb5c33bd7a68ac2f9f3f96b', 'Jenny', 'Kim', 34, 0, 'Full mouth checkup', 'California,USA', '0982414523', 'jenny_kim@yahoo.com', '0');
INSERT INTO `patient` VALUES ('P012', '81dc9bdb52d04dc20036dbd8313ed055', 'test', 'test', 11, 2, 'Braces', 'test', '0982414523', 'test@testmail.com', 'submit');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `patient_appointement`
-- 

CREATE TABLE `patient_appointement` (
  `ID` int(11) NOT NULL auto_increment,
  `patientID` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `treatment` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `dentist` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `patient_appointement`
-- 

INSERT INTO `patient_appointement` VALUES (1, 'P1234567', 'Baitarn', 'Baitarn', 'Tooth fairy', '2014-04-09', '00:00:13', 'Miss Bell');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `queue`
-- 

CREATE TABLE `queue` (
  `qnum` int(11) NOT NULL,
  `patientID` varchar(10) default NULL,
  PRIMARY KEY  (`qnum`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `queue`
-- 

INSERT INTO `queue` VALUES (0, 'pone');
INSERT INTO `queue` VALUES (1, NULL);
INSERT INTO `queue` VALUES (2, NULL);
INSERT INTO `queue` VALUES (3, NULL);
INSERT INTO `queue` VALUES (4, NULL);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `treatment`
-- 

CREATE TABLE `treatment` (
  `tid` int(11) NOT NULL auto_increment,
  `tName` varchar(20) NOT NULL,
  `cost` double NOT NULL,
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- dump ตาราง `treatment`
-- 

INSERT INTO `treatment` VALUES (1, 'Full mouth checkup', 0);
INSERT INTO `treatment` VALUES (2, 'Composite filling', 1000);
INSERT INTO `treatment` VALUES (3, 'Fluoride application', 400);
INSERT INTO `treatment` VALUES (4, 'Consultation', 0);
