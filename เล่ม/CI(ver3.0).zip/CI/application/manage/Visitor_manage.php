<?php

class Visitor_manage extends CI_Controller{
	
	public function view_information(){
		$this->load->database();
	 	$this->load->model('Visitor_Model');
  		return $this->Visitor_Model->get_information();
		}
	public function getAllTreatment(){
		$this->load->database();
		$this->load->model('Visitor_Model');
		return $this->Visitor_Model->get_treatment();
		}
	public function calculate($dent_treat){
		$result=0;
		if($dent_treat['cost']==null){
				return 0;
				}
		else{
			foreach($dent_treat['cost'] as &$value){
				$result += $value;
			
				}
		//echo "value="+$value;
		//print_r("value="+$result);
			return $result;
		}	
		}
	}
	
	
?>