<?php

class Patient_manage extends CI_Controller{
	
	public function login($patientID, $password){
		$this->load->model('Patient_Model');
		//$passwordmd5=md5($password);
		$result=$this->Patient_Model->login($patientID,$password);
		return $result;
		}
	
	public function getCalendarByPID($patientID){
		$this->load->model('Patient_Model');
		$data['user']=$this->Patient_Model->getAppointmentByID($patientID);
		//print_r($data);
		return $data['user'];
		}
	public function get_p_db(){
		$this->load->database();
		$this->load->model('Patient_Model');
		return $this->Patient_Model->get_p_data();
		}
	public function view_follow_up($pid){
		$this->load->database();
		$this->load->model('Patient_Model');
		return $this->Patient_Model->get_follow_up($pid);
		}
	public function viewFollowUpByQid($qid){
		$this->load->database();
		$this->load->model('Patient_Model');
		$data['user'] = $this->Patient_Model->getFollowUpByQid($qid);
		return $data['user'];
		}
	public function answer_data($data){
		$this->load->database();
		$this->load->model('Patient_Model');
		//print_r($data);
		if($data['qid']==null){
			$result = false;
		}
		else{
			$result = $this->Patient_Model->save_answer($data);
			
			}
		return $result;
		}
	public function get_p_DataById($patientID){
		$this->load->database();
		$this->load->model('Patient_Model');
		$data['user'] = $this->Patient_Model->get_p_DataById($patientID);
		return $data['user'];
		}
	public function gen_qr($patientID){
		$this->load->library('ciqrcode');
		//$name=$patientID;
		$params['data'] = $patientID;
		$params['level'] = 'H';
		$params['size'] = 4;
		$params['savename'] = FCPATH.'genp.png';
		return $this->ciqrcode->generate($params);
		//print_r($params['data']);
		}
	public function view_information(){
		$this->load->database();
	 	$this->load->model('Patient_Model');
  		return $this->Patient_Model->get_information();
		}
	public function getAllTreatment(){
		$this->load->database();
		$this->load->model('Patient_Model');
		return $this->Patient_Model->get_treatment();
		}
	public function calculate($dent_treat){
		$result=0;
		if($dent_treat['cost']==null){
				return 0;
				}
		else{
			foreach($dent_treat['cost'] as &$value){
				$result += $value;
			
				}
		//echo "value="+$value;
		//print_r("value="+$result);
			return $result;
		}	
		}
	}
	
	
?>