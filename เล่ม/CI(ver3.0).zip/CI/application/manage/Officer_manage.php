<?php

class Officer_manage extends CI_controller{
	
	public function login($officerID, $password){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->login($officerID,$password);
		return $result;
		}
	public function get_p_db(){
		$this->load->database();
		$this->load->model('Offiecer_Model');
		return $this->Offiecer_Model->get_p_data();
		}
	public function get_db(){
		$this->load->database();
	 	$this->load->model('Offiecer_Model');
  		return $this->Offiecer_Model->get_data();
		}
	public function p_register($data){
		//print_r($data);
		$this->load->model('Offiecer_Model');
				
				$patientID = $data['patientID'];
				$check = $this->Offiecer_Model->checkExist_p($patientID);
				//print_r($patientID);
				//print_r($check);
				if($check==false){
					
					$result = $this->Offiecer_Model->addnew($data);
				//print_r($check);
				//print_r($result);
				//print_r($data);
				return $result;
				}
				else {
					return false;
					}
				return false;
		}
		
	/*	public function test2($patientID){
			$this->load->model('Offiecer_Model');
			return $this->Offiecer_Model->checkExist_p($patientID);
			}
		*/
	public function p_edit($patientID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->get_p_DataById($patientID);
		return $data['user'];
		}	
	public function edit_data($data){
		$this->load->model('Offiecer_Model');
		$result = $this->Offiecer_Model->update($data);
		//echo $this->Offiecer_Model->get_p_data();
		return $result;
		}
	public function p_delete($patientID){
		$this->load->model('Offiecer_Model');
  		$result = $this->Offiecer_Model->delete($patientID);
		return $result;
		//echo $this->Offiecer_Model->get_p_data();
		}
	public function d_register($data){
		$this->load->model('Offiecer_Model');
				
		$dentistID = $data['dentistID'];
				print_r($data);
		$check = $this->Offiecer_Model->checkExist_d($dentistID);
		print_r($check);
		if($check==false){
			
			$result = $this->Offiecer_Model->addnew_d($data);
			return $result;
			}
		else{
			return false;
			}
		}
		
	public function d_edit($dentistID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getDataById($dentistID);
		return $data['user'];
		}
	public function d_edit_data($data){
			
		$this->load->model('Offiecer_Model');
		$result = $this->Offiecer_Model->d_update($data);
		return $result;
		}
	public function d_delete($dentistID){
		$this->load->model('Offiecer_Model');
  		$result = $this->Offiecer_Model->d_delete($dentistID);
		//echo $this->Offiecer_Model->get_data();
		return $result;
		}
	public function view_appointment(){
		$this->load->database();
	  	$this->load->model('Offiecer_Model');
  		return $this->Offiecer_Model->get_appointment();
		}
	public function test($dentistID,$aDate,$startTime){
			$this->load->model('Offiecer_Model');
			return $this->Offiecer_Model->checkDuplicate_app($dentistID,$aDate,$startTime);
			}
	/*public function make_appointment($data){
		$this->load->model('Offiecer_Model');
		$patientID = $data['patientID'];
		$dentistID = $data['dentistID'];
		$aDate = $data['aDate'];
    	$startTime = $data['startTime'];
		$endTime = $data['endTime'];
		
		$this->load->helper('date');
		$timestring = "%H:%i:%s";
		$time = time();
		$human = unix_to_human($time, TRUE, 'eu');
		$unix = human_to_unix($human);
		$dataT['time'] = mdate($timestring, $unix);
		$datestring = "%Y-%m-%d";
		$dataT['date'] = mdate($datestring, $time);
		
		//$result_status = arrray();
		
		if($aDate>=$dataT['date']){
			if($startTime<$endTime){
				if($startTime>$dataT['time']){
					$checkPatientID = $this->Offiecer_Model->checkExist_p($patientID);	
					$checkDentID = $this->Offiecer_Model->checkExist_d($dentistID);
					if($checkPatientID==true&&$checkDentID==true){
						$result_dent = $this->Offiecer_Model->dent_check($dentistID,$aDate,$startTime);
						$result_patient = $this->Offiecer_Model->patient_check($patientID,$aDate,$startTime);
							if($result_dent==true&&$result_patient==true){
								$result_add = $this->Offiecer_Model->make_new($data);
								return $result_add;
								echo 'both true';
								}
			
							else{
								echo 'any false';
								return false;
								}
						}
					else{
						echo 'noID';
						return false;
						}
					}
				else{
					echo 'past time';
					return false;
					}
				}
			else{
				echo 'end time incorrect';
				return false;
				}
			}
		else{
			echo 'past day';
			return false;
			}
		}*/
	public function app_delete($appointmentID){
		$this->load->model('Offiecer_Model');
  		$result = $this->Offiecer_Model->app_delete($appointmentID);
		//echo $this->Offiecer_Model->get_appointment();
		return $result;
		}
	public function app_edit($appointmentID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByAppointmentId($appointmentID);
		return $data['user'];
		}
	public function app_edit_data($data){
		
		$this->load->model('Offiecer_Model');
		$result = $this->Offiecer_Model->appointment_update($data);
		return $result;
		}
	public function save_appointment($appointmentID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByAppointmentId($appointmentID);
		return $data;
		}
	public function patientCalendar($patientID){
		$this->load->database();
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByPID($patientID);
		return $data['user'];
		}
	public function dentistCalendar($dentistID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->getAppointmentByDID($dentistID);
		return $data['user'];
		}
		
	public function get_treatment(){
		$this->load->database();
	 	$this->load->model('Offiecer_Model');
  		return $this->Offiecer_Model->get_treatment();
		}
	public function add_dental_treatment($data){
		$this->load->model('Offiecer_Model');
				
		$tid = $data['tid'];
				print_r($data);
		$check = $this->Offiecer_Model->checkDuplicate_dental($tid);
		print_r($check);
		if($check==true){
			
			$result = $this->Offiecer_Model->addnew_dental($data);
			return $result;
			}
		else{
			return false;
			}
		}
	public function edit_dental_treatment($tid){
		$this->load->database();
	 	$this->load->model('Offiecer_Model');
  		$data['treatment'] = $this->Offiecer_Model->getTreatmentById($tid);
		return $data['treatment'];
		}
	public function edit_dental_treatment_data($data){
		$this->load->database();
		$this->load->model('Offiecer_Model');
		$result = $this->Offiecer_Model->update_treatment($data);
		return $result;
		}
	public function delete_treatment($tid){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->delete_treatment($tid);
		return $result;
		}
	public function get_information(){
		$this->load->database();
	 	$this->load->model('Offiecer_Model');
  		return $this->Offiecer_Model->get_information();
		}
	public function add_information($data){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->add_information($data);
		return $result;
		}
	public function edit_info($infoID){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->getInfoByInfoId($infoID);
		return $result;
		}
	public function edit_info_data($data){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->edit_information($data);
		return $result;
		}
	public function delete_info($infoID){
		$this->load->model('Offiecer_Model');
		$result=$this->Offiecer_Model->delete_info($infoID);
		return $result;
		}
	public function p_detail($patientID){
		$this->load->model('Offiecer_Model');
		$data['user']=$this->Offiecer_Model->get_p_DataById($patientID);
		return $data['user'];
		}
	public function gen_qr($patientID){
		$this->load->library('ciqrcode');
		//$name=$patientID;
		$code = "http://localhost/CI/index.php/Officer_Controller/p_detail/".(string)$patientID;
		$params['data'] = $code;
		$params['level'] = 'H';
		$params['size'] = 4;
		$params['savename'] = FCPATH.'test.png';
		return $this->ciqrcode->generate($params);
		//print_r($params['data']);
		}
	public function check_time($pid){
		$this->load->helper('date');
		$timestring = "%H:%i:%s";
		$time = time();
		$data['time'] = mdate($timestring, $time);
		$datestring = "%Y-%m-%d";
		$data['date'] = mdate($datestring, $time);
		$data['pid'] = $pid;
		$result = array();
		$data['appointment']=$this->patientCalendar($pid);
		if($data['appointment']!=null){
			//$result[] = $data['appointment'];
			foreach($data['appointment'] as $key => $value){
				if($value->aDate==$data['date']){
					//$result[] = 'date ok';
					if($value->startTime>=$data['time']){
						//$result[] = true;
						$result[] = 'ok';
						}
					else{
						//$result[] = false;
						$result[] = 'you missed';
						}
					}
				else{
					//$result[] = false;
					$result[] = 'not today';
					}
				}
			}
		else{
			//$result[] = false;
			$result[] = 'no appointment';
			}
		return $result;
		}
	
	public function add_queue($pid,$q){
		$data['patientID'] = $pid;
		$this->load->model('Offiecer_Model');
		$data2['allq'] = $this->Offiecer_Model->get_queue();
		$oldpid =$this->load->model('Offiecer_Model');
		foreach ($data2['allq'] as $key => $value) {
			if($value->patientID==null){
				if($value->qnum==$q){
					$data2['result']=$this->Offiecer_Model->add_queue($data,$q);
					print_r($data2['allq']);
					echo 'nullbefore';
					return $data2['result'];
					}
				break;
				}
			elseif($value->patientID!=null){
				//if($value->qnum==$q){
					$oldpid = array();
					//*print_r($value);
					if($value->patientID==$pid){
						for($i=0; $i<=count(get_object_vars($value));$i++){
						if($value->qnum==$i){
							$oldpid[$i] = $value->patientID;
							//print_r($value->patientID);
							//print_r($oldpid[$i]);
							}
						elseif($value->patientID==null){
							break;
							}
						}
					//print_r($oldpid);
					$data['patientID'] = $pid;
					print_r($data['patientID']);
					$data2['result']=$this->Offiecer_Model->add_queue($data,$q);
					$y=1;
					foreach($oldpid as $key => $old){
						$data['patientID'] = $old;
						$data2['result']=$this->Offiecer_Model->add_queue($data,$q+$y);
							print_r($data['patientID']);
						$y=$y+1;
						}
					//}
					return $data2['result'];
						}
				}
			else{
				return false;
				}
			}
		
		}
		public function all_queue(){
			$this->load->model('Offiecer_Model');
			$data['allq'] = $this->Offiecer_Model->get_queue();
			return $data['allq'];
			}
		public function reset_queue(){
			$this->load->model('Offiecer_Model');
			$data['allq'] = $this->Offiecer_Model->reset_queue();
			return $data['allq'];
			}
		public function checkselect($data){
			$this->load->model('Offiecer_Model');
			$time = $data['startTime'];
			$dent = $data['dentistID'];
			$date = $data['aDate'];
			$result = $this->Offiecer_Model->checkselect($dent,$date,$time);
			if($result=true){
				//$result_add = $this->Offiecer_Model->make_new($data);
				//return $result_add;
				echo 'true';
				}
			else{
				echo 'false';
				//return false;
				}
		/*	for($i=0;$i<=count(get_object_vars($result));$i++){
				if($result[$i]==$date){
					return $result[$i];
					//break;
				}
			}*/
			//return $result;
			}
		public function make_appointment($data){
		$this->load->model('Offiecer_Model');
		$patientID = $data['patientID'];
		$dentistID = $data['dentistID'];
		$aDate = $data['aDate'];
    	$startTime = $data['startTime'];
		$endTime = $data['endTime'];
		
		$this->load->helper('date');
		$timestring = "%H:%i:%s";
		$time = time();
		$human = unix_to_human($time, TRUE, 'eu');
		$unix = human_to_unix($human);
		$dataT['time'] = mdate($timestring, $unix);
		$datestring = "%Y-%m-%d";
		$dataT['date'] = mdate($datestring, $time);
		
		$result_status = array();
		
		//date past
		if($aDate<$dataT['date']){
			$result['status'] = 'past day';
			$result['result'] = false;
			}
		// appoint for next day
		else if($aDate>$dataT['date']){
			if($data['startTime']<$data['endTime']){
					$checkPatientID = $this->Offiecer_Model->checkExist_p($patientID);	
					$checkDentID = $this->Offiecer_Model->checkExist_d($dentistID);
					if($checkPatientID==true&&$checkDentID==true){
						$result_dent = $this->Offiecer_Model->dent_check($dentistID,$aDate,$startTime);
						$result_patient = $this->Offiecer_Model->patient_check($patientID,$aDate,$startTime);
							if($result_dent==true&&$result_patient==true){
								$result['result'] = $this->Offiecer_Model->make_new($data);
								//return $result;
								//$result['result'] = true;
								$result['status'] = 'Done';
								//return array($result_status,$result);
								}
			
							else{
								$result['status'] = 'any false';
								$result['result']  = false;
								}
						}
					else{
						$result['status'] = 'noID';
						$result['result'] = false;
						}
				}
			else{
				$result['status'] = 'end time incorrect';
				print_r($startTime);
				$result['result'] = false;
				}
			}
		//appoint for today
		else if($aDate=$dataT['date']){
			if($data['startTime']<$data['endTime']){
				if($data['startTime']>$dataT['time']){
					$checkPatientID = $this->Offiecer_Model->checkExist_p($patientID);	
					$checkDentID = $this->Offiecer_Model->checkExist_d($dentistID);
					if($checkPatientID==true&&$checkDentID==true){
						$result_dent = $this->Offiecer_Model->dent_check($dentistID,$aDate,$startTime);
						$result_patient = $this->Offiecer_Model->patient_check($patientID,$aDate,$startTime);
							if($result_dent==true&&$result_patient==true){
								$result['result'] = $this->Offiecer_Model->make_new($data);
								//return $result_add;
								//$result['result'] = true;
								$result['status'] = 'Done';
								//return $result_status;
								}
			
							else{
								$result['status'] = 'any false';
								$result['result'] = false;
								}
						}
					else{
						$result['status'] = 'noID';
						$result['result'] = false;
						}
					}
				else{
					$result['status'] = 'past time';
					$result['result'] = false;
					}
				}
			else{
				$result['status'] = 'end time incorrect';
				$result['result'] = false;
				}
			}
		//appoint the past
		else{
			$result['status'] = 'past day';
			$result['result'] = false;
			}
		return $result;
		}
	
	}
?>