<?php 

class Visitor_Model extends CI_Model{
	
	function get_information(){
	   	$this->load->database();
		$query = $this->db->get('information');
		if ( $query->num_rows() > 0 ) {
			$output['dbrow'] = $query->result();
		} else {
			$output['dbrow'] = null;
		}
		$query->free_result();
		return $output['dbrow'];
	   }
	public function get_treatment(){
		$this->load->database();
        $query = $this->db->get('treatment'); // Select the table products
        return $query->result_array(); // Return the results in a array.
		}
	}

?>