<?php
require_once APPPATH."manage/Patient_manage.php";
class TestPatient_manage extends CI_Controller
{
	public function testp_login()
	{
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$in_user_f = "xxxxxx";
		$in_pass_f = "xxxxxx";
		$expResult1 = false;
		
		$actResult1 = $patient->login($in_user_f, $in_pass_f);
		echo $this->unit->run($expResult1, $actResult1, "test login -> both incorrect");
		
		$in_user_t = "P001";
		$in_pass_t = "1234";
		$expResult2 = true;
		
		$actResult2 = $patient->login($in_user_t, $in_pass_t);
		echo $this->unit->run($expResult2, $actResult2, "test login -> both correct");
		
		$actResult3 = $patient->login($in_user_t,$in_pass_f);
		echo $this->unit->run($expResult1, $actResult3, "test login -> correct username, incorrect password");
		
		$actResult4 = $patient->login($in_user_f,$in_pass_t);
		echo $this->unit->run($expResult1, $actResult4, "test login -> incorrect username, correct password");
	}
	
	public function testp_ownCalendar(){
		
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$in_id_f = "xxxx";
		$expResult1 = null; 
		$actResult1 = $patient->getCalendarByPID($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_t = "P001";
		//$expResult2 = true;
		//$expResult2 = array('1','1','test','2014-06-08','13:00:00','13:30:00','Bridge','-');
		//Array ( [dbrow] => Array ( [0] => stdClass Object ( [appointmentID] => 1 [patientID] => 1 [userID] => test [aDate] => 2014-06-08 [startTime] => 13:00:00 [endTime] => 13:30:00 [treatment] => Bridge [description] => - ) ) )
		
		$x2 = $this->load->model('Patient_Model');
		$x2->appointmentID = 1;
		$x2->patientID = 'P001';
		$x2->dentistID = 'D001';
		$x2->aDate = '2014-08-01';
		$x2->startTime = '09:00:00';
		$x2->endTime = '09:30:00';
		$x2->treatment = 'Tooth braces';
		$x2->description = '100 baht';
		$x2->submit = 'Submit';
		//$expResult2[0] = array("appointmentID"=>1,"patientID"=>'1',"userID"=>'test',"aDate"=>'2014-06-08',"startTime"=>'13:00:00',"endTime"=>'13:30:00',"treatment"=>'Bridge',"description"=>'-');
		$expResult2[0] = $x2; 
		$actResult2 = $patient->getCalendarByPID($in_id_t);
		
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		
		}
		
//progress 2
		
	public function testp_getAllTreatment(){
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$x = array('tid'=>1,'tName'=>'Full mouth checkup','cost'=>0);
		$expResult[0] = $x;
		
		$x2 = array('tid'=>2,'tName'=>'Composite filling','cost'=>1000);
		$expResult[1] = $x2;
		
		$x3 = array('tid'=>3,'tName'=>'Fluoride application','cost'=>400);
		$expResult[2] = $x3;
		
		$x4 = array('tid'=>4,'tName'=>'Consultation','cost'=>0);
		$expResult[3] = $x4;
		$actResult = $patient->getAllTreatment();
		
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		echo $this->unit->run($expResult, $actResult, "test view all dental treatment -> true case");
		}
	public function testp_caculate(){
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$x = array('0'=>0);
		$in_treat1['cost'] = $x;
		
		$result1 = 0;
		
		$actResult = $patient->calculate($in_treat1);
		//print_r($in_treat1);
		echo "exp >>> ";print_r($result1); echo "</br>";
		echo "act >>> ";print_r($actResult);
		echo $this->unit->run($result1, $actResult, "test calculate -> 0 case");
		
		$x2 = array('0'=>1000,'1'=>400);
		$in_treat2['cost'] = $x2;
		
		$result2 = 1400;
		
		$actResult2 = $patient->calculate($in_treat2);
		echo "exp >>> ";print_r($result2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($result2, $actResult2, "test calculate -> 1400 case");
		
		$x3 = array('0'=>null);
		$in_treat3['cost'] = $x3;
		
		$actResult3 = $patient->calculate($in_treat3);
		//print_r($in_treat1);
		echo "exp >>> ";print_r($result1); echo "</br>";
		echo "act >>> ";print_r($actResult3);
		echo $this->unit->run($result1, $actResult3, "test calculate -> null case");
		}
	public function testp_get_information(){
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$x = $this->load->model('Patient_Model');
		$x->infoID = 1;
		$x->type = 'promo';
		$x->title = 'Free checkup';
		$x->details = 'Full mouth checkup for free at the clinic';
		$x->officerID = 'OF001';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Patient_Model');
		$x2->infoID = 2;
		$x2->type = 'info';
		$x2->title = 'EF Line';
		$x2->details = 'EF Line is tooth braces for children between 4-15 years old';
		$x2->officerID = 'OF001';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Patient_Model');
		$x3->infoID = 3;
		$x3->type = 'promo';
		$x3->title = 'Whitening 30% off';
		$x3->details = 'End of the year sale, whitening treatment is noe 30% off';
		$x3->officerID = 'OF002';
		$expResult[2] = $x3;
		
		$actResult = $patient->view_information();
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		echo $this->unit->run($expResult, $actResult, "test view all information -> true case");
		}
	public function testp_viewFollowUpByQid(){
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$in_qid1 = 14;
		//$x = array('tid'=>1,'tName'=>'Full mouth checkup','cost'=>0);
		$expResult1 = array('qid'=>14,
			'patientID'=>'P001',
			'dentistID'=>'D001',
			'question'=>'How are your composite filling? Is that fine?',
			'answer'=>null,
			'qDateTime'=>'2014-10-19 11:04:35',
			'aDateTime'=>null);
	
		//$expResult[0] = $x;
		
		$actResult1 = $patient->viewFollowUpByQid($in_qid1);
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		echo $this->unit->run($expResult1, $actResult1, "test view follow up by qid -> true case");
		
		$in_qid2 = 15;
		$expResult2 = null;
		
		$actResult2 = $patient->viewFollowUpByQid($in_qid2);
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test view follow up by qid -> false case");
		}
	public function testp_answer_data(){
		$this->load->library("unit_test");
		$patient = new Patient_manage();
		
		$in_data = array('qid'=>14,
			'patientID'=>'P001',
			'dentistID'=>'D001',
			'question'=>'How are your composite filling? Is that fine?',
			'answer'=>'Nothing wrong, still fine',
			'qDateTime'=>'2014-10-19 11:04:35',
			'aDateTime'=>'2014-10-19 19:39.00');
		$expResult1 = true;
		
		$actResult1 = $patient->answer_data($in_data);
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		echo $this->unit->run($expResult1, $actResult1, "test answer data-> true case");
		
		$in_data2 = array('qid'=>null);
		$expResult2 = false;
		
		$actResult2 = $patient->answer_data($in_data2);
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test answer data-> false case");
		}
		
		public function testp_view_follow_up(){
			$this->load->library("unit_test");
			$patient = new Patient_manage();
			
			$in_pid = 'P002';
			
			$x = $this->load->model('Patient_Model');
			$x->qid = 13;
			$x->patientID = 'P002';
			$x->dentistID = 'D002';
			$x->question = 'Your retainer is ready in next 3 days (2014-10-15) please come an pick it up at the clinic anytime';
			$x->answer = 'Ok, thank you very much';
			$x->qDateTime = '2014-10-12 09:15:22';
			$x->aDateTime = '2014-10-13 08:00:28';
			$expResult[0] = $x;
			
			
			$actResult = $patient->view_follow_up($in_pid);
			echo "exp >>> ";print_r($expResult); echo "</br>";
			echo "act >>> ";print_r($actResult);
			echo $this->unit->run($expResult, $actResult, "test view follow up-> true case");
		}
		public function testp_view_detail(){
			$this->load->library("unit_test");
			$patient = new Patient_manage();
			
			$in_pid = 'P001';
			
			$x = $this->load->model('Patient_Model');
			$x->patientID = 'P001';
			$x->password = '1234';
			$x->f_name = 'Mickey';
			$x->l_name = 'Mouse';
			$x->age = 80;
			$x->gender = 1;
			$x->treatment = 'Braces';
			$x->address = 'Chaingmai Thailand';
			$x->tel = '053111111';
			$x->email = 'M.ky@hotmail.com';
			$x->submit = '0';
			$expResult[0] = $x;
			
			$actResult = $patient->get_p_DataById($in_pid);
			echo "exp >>> ";print_r($expResult); echo "</br>";
			echo "act >>> ";print_r($actResult);
			echo $this->unit->run($expResult, $actResult, "test view patients' details-> true case");
			}
			
}
?>