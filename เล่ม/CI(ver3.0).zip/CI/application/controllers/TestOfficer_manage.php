<?php
require_once APPPATH."manage/Officer_manage.php";

class TestOfficer_manage extends CI_controller{
	
	public function testLogin(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_user_f = "xxxx";
		$in_pass_f = "xxxx";
		$expResult1 = false;
		
		$actResult1 = $officer->login($in_user_f, $in_pass_f);
		echo $this->unit->run($expResult1, $actResult1, "test login -> both incorrect");
		
		$in_user_t = "OF001";
		$in_pass_t = "1234";
		$expResult2 = true;
		
		$actResult2 = $officer->login($in_user_t, $in_pass_t);
		echo $this->unit->run($expResult2, $actResult2, "test login -> both correct");
		
		$actResult3 = $officer->login($in_user_t,$in_pass_f);
		echo $this->unit->run($expResult1, $actResult3, "test login -> correct username, incorrect password");
		
		$actResult4 = $officer->login($in_user_f,$in_pass_t);
		echo $this->unit->run($expResult1, $actResult4, "test login -> incorrect username, correct password");
		}
		
	public function testget_p_db(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->patientID = 'P001';
		$x->password = '1234';
		$x->f_name = 'Mickey';
		$x->l_name = 'Mouse';
		$x->age = 80;
		$x->gender = 1;
		$x->treatment = 'Tooth braces,tooth zeplin';
		$x->address = 'Chaingmai Thailand';
		$x->tel = '053111111';
		$x->email = 'M.ky@hotmail.com';
		$x->submit = 'Submit';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->patientID = 'P002';
		$x2->password = '1111';
		$x2->f_name = 'Minnie';
		$x2->l_name = 'Mouse';
		$x2->age = 80;
		$x2->gender = 2;
		$x2->treatment = 'Tooth braces,tooth zeplin';
		$x2->address = 'New York,USA';
		$x2->tel = '0120000000';
		$x2->email = 'M.Nie@hotmail.com';
		$x2->submit = 'Submit';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->patientID = 'P003';
		$x3->password = '5555';
		$x3->f_name = 'Goofy';
		$x3->l_name = 'Goof';
		$x3->age = 4;
		$x3->gender = 1;
		$x3->treatment = 'EF line';
		$x3->address = 'California,USA';
		$x3->tel = '0230000000';
		$x3->email = 'GG@yahoo.com';
		$x3->submit = 'Submit';
		$expResult[2] = $x3;
		
		$actResult = $officer->get_p_db();
		
		echo $this->unit->run($expResult, $actResult, "test view all patient -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
	}	
		
	public function testget_db(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->dentistID = 'D001';
		$x->password = '1234';
		$x->f_name = 'Donald';
		$x->l_name = 'Duck';
		$x->address = 'Chaingmai Thailand';
		$x->email = 'DD@gmail.com';
		$x->tel = '0810000000';
		$x->submit = null;
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->dentistID = 'D002';
		$x2->password = '6789';
		$x2->f_name = 'Daisy';
		$x2->l_name = 'Duck';
		$x2->address = 'New York,USA';
		$x2->email = 'D_lady@hotmail.com';
		$x2->tel = '0810000001';
		$x2->submit = 'Submit';
		$expResult[1] = $x2;
		
		$actResult = $officer->get_db();
		
		echo $this->unit->run($expResult, $actResult, "test view all dentist -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}	
		
	public function testp_register(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$data = array(
			'patientID'=>'P004',
			'password'=>'1234',
			'f_name'=>'Mickey',
			'l_name'=>'Mouse',
			'age'=>80,
			'gender'=>1,
			'treatment'=>'Tooth braces,tooth zeplin',
			'address'=>'Chaingmai Thailand',
			'tel'=>'053111111',
			'email'=>'M.ky@hotmail.com',
			'submit'=>'Submit');
		
		echo "data >>> ";print_r($data);
		$expResult1 = true;
		$actResult1 = $officer->p_register($data);
		echo $this->unit->run($expResult1, $actResult1, "test register for patient -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1); echo "</br>";
		
		$data2 = array(
			'patientID'=>'P001',
			'password'=>'1234',
			'f_name'=>'Mickey',
			'l_name'=>'Mouse',
			'age'=>80,
			'gender'=>1,
			'treatment'=>'Tooth braces,tooth zeplin',
			'address'=>'Chaingmai Thailand',
			'tel'=>'053111111',
			'email'=>'M.ky@hotmail.com',
			'submit'=>'Submit');
			
		$expResult2 = false;
		$actResult2 = $officer->p_register($data2);
		echo $this->unit->run($expResult2, $actResult2, "test register for patient -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		
		}
	public function testp_edit(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_f = 'P000';
		$expResult1 = null;	
		
		$actResult1 = $officer->p_edit($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test call patients' data to edit -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_t = 'P001';
		$expResult2 = array('patientID'=>'P001','password'=>'1234','f_name'=>'Mickey','l_name'=>'Mouse','age'=>80,'gender'=>1,'treatment'=>'Tooth braces,tooth zeplin','address'=>'Chaingmai Thailand','tel'=>'053111111','email'=>'M.ky@hotmail.com','submit'=>'Submit');	
		
		$actResult2 = $officer->p_edit($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test call patients' data to edit -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testp_delete(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_t = 'P004';
		$expResult2 = true;
		$actResult2 = $officer->p_delete($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test delete patients' account -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		
	public function testd_register(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$data = array(
			'dentistID'=>'D003',
			'password'=>'1234',
			'f_name'=>'dent',
			'l_name'=>'tist',
			'address'=>'clinic',
			'tel'=>'0000000000',
			'email'=>'dentist.t@clinic.com',
			'submit'=>'Submit');
			
		$expResult = true;
		$actResult = $officer->d_register($data);
		echo $this->unit->run($expResult, $actResult, "test register for dentist -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		
		$data2 = array(
			'dentistID'=>'D001',
			'password'=>'1234',
			'f_name'=>'John',
			'l_name'=>'Doe',
			'address'=>'Munich, Germany',
			'tel'=>'0000000000',
			'email'=>'j.doe@clinic.com',
			'submit'=>'Submit');
		
		$expResult2 = false;
		$actResult2 = $officer->d_register($data2);
		echo $this->unit->run($expResult2, $actResult2, "test register for dentist -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testd_edit(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_f = 'P0000';
		$expResult1 = null;	
		
		$actResult1 = $officer->d_edit($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test call dentists' data to edit -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_t = 'D002';
		$expResult2 = array('dentistID'=>'D002','password'=>'6789','f_name'=>'Daisy','l_name'=>'Duck','address'=>'New York,USA','email'=>'D_lady@hotmail.com','tel'=>'0810000001','submit'=>'Submit');	
		
		$actResult2 = $officer->d_edit($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test call dentists' data to edit -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		
	public function testd_delete(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_t = '0';
		$expResult2 = true;
		$actResult2 = $officer->d_delete($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test delete dentists' accout -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		
	public function testview_appointment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->appointmentID = 1;
		$x->patientID = 'P001';
		$x->dentistID = 'D001';
		$x->aDate = '2014-08-01';
		$x->startTime = '09:00:00';
		$x->endTime = '09:30:00';
		$x->treatment = 'Tooth braces';
		$x->description = '100 baht';
		$x->submit = 'Submit';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->appointmentID = 2;
		$x2->patientID = 'P002';
		$x2->dentistID = 'D002';
		$x2->aDate = '2014-08-05';
		$x2->startTime = '13:00:00';
		$x2->endTime = '14:00:00';
		$x2->treatment = 'Whitening';
		$x2->description = '1000 baht';
		$x2->submit = 'Submit';
		$expResult[1] = $x2;
		
		
		$actResult = $officer->view_appointment();
		
		echo $this->unit->run($expResult, $actResult, "test view all appointment in schedule -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
		
	public function testmake_appointment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
					
		$expResult_t = true;
		$expResult_f = false;
		
		$data = array(
			'patientID'=>'P001',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-17',
			'startTime'=>'10:00:00',
			'endTime'=>'10:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	

		$result = $officer->make_appointment($data);
		$actResult = $result['result'];
		echo $this->unit->run($expResult_t, $actResult, "test make appointment -> true case1");
		echo "exp >>> ";print_r($expResult_t); echo "</br>";
		echo "act >>> ";print_r($actResult);
		
		$data2 = array(
			'patientID'=>'P002',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-17',
			'startTime'=>'10:30:00 ',
			'endTime'=>'11:00:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
			
		$result2 = $officer->make_appointment($data2);
		$actResult2 = $result2['result'];
		echo $this->unit->run($expResult_t, $actResult2, "test make appointment -> true case2");
		echo "exp >>> ";print_r($expResult_t); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		
		$data3 = array(
			'patientID'=>'P003',
			'dentistID'=>'D002',
			'aDate'=>'2014-12-17',
			'startTime'=>'10:00:00 ',
			'endTime'=>'10:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
			
		$result3 = $officer->make_appointment($data3);
		$actResult3 = $result3['result'];
		echo $this->unit->run($expResult_t, $actResult3, "test make appointment -> true case3");
		echo "exp >>> ";print_r($expResult_t); echo "</br>";
		echo "act >>> ";print_r($actResult3);
		
		$data4 = array(
			'patientID'=>'P004',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-17',
			'startTime'=>'10:00:00 ',
			'endTime'=>'10:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result4 = $officer->make_appointment($data4);
		$actResult4 = $result4['result'];
		echo $this->unit->run($expResult_f, $actResult4, "test make appointment -> false case");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult4);
		
		$data5 = array(
			'patientID'=>'P001',
			'dentistID'=>'D003',
			'aDate'=>'2014-12-17',
			'startTime'=>'11:00:00 ',
			'endTime'=>'11:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	

		$result5 = $officer->make_appointment($data5);
		$actResult5 = $result5['result'];
		echo $this->unit->run($expResult_t, $actResult5, "test make appointment -> true case4");
		echo "exp >>> ";print_r($expResult_t); echo "</br>";
		echo "act >>> ";print_r($actResult5);
		
		$data6 = array(
			'patientID'=>'P002',
			'dentistID'=>'D003',
			'aDate'=>'2014-12-17',
			'startTime'=>'10:30:00 ',
			'endTime'=>'11:00:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result6 = $officer->make_appointment($data6);
		$actResult6 = $result6['result'];
		echo $this->unit->run($expResult_f, $actResult6, "test make appointment -> false case2");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult6);
		
		$data7 = array(
			'patientID'=>'P001',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-17',
			'startTime'=>'19:00:00 ',
			'endTime'=>'19:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	

		$result7 = $officer->make_appointment($data7);
		$actResult7 = $result7['result'];
		echo $this->unit->run($expResult_t, $actResult7, "test make appointment -> true case5");
		echo "exp >>> ";print_r($expResult_t); echo "</br>";
		echo "act >>> ";print_r($actResult7);
		
		$data8 = array(
			'patientID'=>'P002',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-16',
			'startTime'=>'10:00:00 ',
			'endTime'=>'10:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result8 = $officer->make_appointment($data8);
		$actResult8 = $result8['result'];
		echo $this->unit->run($expResult_f, $actResult8, "test make appointment -> false case3");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult8);
		
		$data9 = array(
			'patientID'=>'P003',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-15',
			'startTime'=>'19:00:00 ',
			'endTime'=>'19:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result9 = $officer->make_appointment($data9);
		$actResult9 = $result9['result'];
		echo $this->unit->run($expResult_f, $actResult9, "test make appointment -> false case4");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult9);
		
		$data10 = array(
			'patientID'=>'P004',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-15',
			'startTime'=>'10:00:00 ',
			'endTime'=>'10:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result10 = $officer->make_appointment($data10);
		$actResult10 = $result10['result'];
		echo $this->unit->run($expResult_f, $actResult10, "test make appointment -> false case5");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult10);
		
		$data11 = array(
			'patientID'=>'P001',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-16',
			'startTime'=>'14:00:00 ',
			'endTime'=>'14:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result11 = $officer->make_appointment($data11);
		$actResult11 = $result11['result'];
		echo $this->unit->run($expResult_t, $actResult11, "test make appointment -> true case6");
		echo "exp >>> ";print_r($expResult_t); echo "</br>";
		echo "act >>> ";print_r($actResult11);
		
		$data12 = array(
			'patientID'=>'P002',
			'dentistID'=>'D002',
			'aDate'=>'2014-12-16',
			'startTime'=>'13:30:00 ',
			'endTime'=>'13:00:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result12 = $officer->make_appointment($data12);
		$actResult12 = $result12['result'];
		echo $this->unit->run($expResult_f, $actResult12, "test make appointment -> false case6");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult12);
		
		$data13 = array(
			'patientID'=>'P020',
			'dentistID'=>'D001',
			'aDate'=>'2014-12-16',
			'startTime'=>'14:00:00 ',
			'endTime'=>'14:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result13 = $officer->make_appointment($data13);
		$actResult13 = $result13['result'];
		echo $this->unit->run($expResult_f, $actResult13, "test make appointment -> false case7");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult13);
		
		$data14 = array(
			'patientID'=>'P001',
			'dentistID'=>'D030',
			'aDate'=>'2014-12-16',
			'startTime'=>'14:00:00 ',
			'endTime'=>'14:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result14 = $officer->make_appointment($data14);
		$actResult14 = $result14['result'];
		echo $this->unit->run($expResult_f, $actResult14, "test make appointment -> false case8");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult14);
		
		$data15 = array(
			'patientID'=>'P020',
			'dentistID'=>'D030',
			'aDate'=>'2014-12-16',
			'startTime'=>'14:00:00 ',
			'endTime'=>'14:30:00',
			'treatment'=>'Whitening',
			'description'=>'4500 THB',
			'submit'=>'Submit');	
	
		$result15 = $officer->make_appointment($data15);
		$actResult15 = $result15['result'];
		echo $this->unit->run($expResult_f, $actResult15, "test make appointment -> false case9");
		echo "exp >>> ";print_r($expResult_f); echo "</br>";
		echo "act >>> ";print_r($actResult15);
		}
	public function testapp_edit(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_f = 4;
		$expResult1 = null;	
		
		$actResult1 = $officer->app_edit($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test call appointments' data to edit -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_t = 2;
		$expResult2 = array('appointmentID'=>2,'patientID'=>'P002','dentistID'=>'D002','aDate'=>'2014-08-05','startTime'=>'13:00:00','endTime'=>'14:00:00','treatment'=>'Whitening','description'=>'1000 baht','submit'=>'Submit');	
		
		$actResult2 = $officer->app_edit($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test call appointments' data to edit -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		
	public function testapp_delete(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_t = '3';
		$expResult2 = true;
		$actResult2 = $officer->app_delete($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test delete appointment -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);	
		}
	public function testPatientCalendar(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_f = 'P0002';
		$expResult1 = null;
		$actResult1 = $officer->patientCalendar($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test view patient own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_t = 'P001';
		//$expResult2 = array('appointmentID'=>8,'patientID'=>'P0001','userID'=>'0','aDate'=>'2014-06-17','startTime'=>'14:00:00','endTime'=>'15:00:00','treatment'=>'clean','description'=>'300 thb','submit'=>null);	
		$x = $this->load->model('Offiecer_Model');
		$x->appointmentID = 1;
		$x->patientID = 'P001';
		$x->dentistID = 'D001';
		$x->aDate = '2014-08-01';
		$x->startTime = '09:00:00';
		$x->endTime = '09:30:00';
		$x->treatment = 'Tooth braces';
		$x->description = '100 baht';
		$x->submit = 'Submit';
		$expResult2[0] = $x;
		
		$actResult2 = $officer->patientCalendar($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test view patient own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		
	public function testDentistCalendar(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_id_f = 'dent001';
		$expResult1 = null;
		$actResult1 = $officer->dentistCalendar($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test view dentist own schedule -> false case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_id_t = 'D002';
		//$expResult2 = array('appointmentID'=>8,'patientID'=>'P0001','userID'=>'0','aDate'=>'2014-06-17','startTime'=>'14:00:00','endTime'=>'15:00:00','treatment'=>'clean','description'=>'300 thb','submit'=>null);	
		$x = $this->load->model('Offiecer_Model');
		$x->appointmentID = 2;
		$x->patientID = 'P002';
		$x->dentistID = 'D002';
		$x->aDate = '2014-08-05';
		$x->startTime = '13:00:00';
		$x->endTime = '14:00:00';
		$x->treatment = 'Whitening';
		$x->description = '1000 baht';
		$x->submit = 'Submit';
		$expResult2[0] = $x;
		
		$actResult2 = $officer->dentistCalendar($in_id_t);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
		
//progress 2

	public function testo_addDentalTreatment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_data1 = array('tid'=>5,'tName'=>'Extraction','cost'=>800);
		$expResult1 = $in_data1;
		
		$actResult1 = $officer->add_dental_treatment($in_data1);
		echo $this->unit->run($expResult1, $actResult1, "test add dental treatment -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_data2 = array('tid'=>4,'tName'=>'Extraction','cost'=>800);
		$expResult2 = null;
		
		$actResult2 = $officer->add_dental_treatment($in_data2);
		echo $this->unit->run($expResult2, $actResult2, "test add dental treatment -> false case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testo_editDentalTreatment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_tid1 = 5;
		$expResult1 = array('tid'=>5,'tName'=>'Extraction','cost'=>800);
		$actResult1 = $officer->edit_dental_treatment($in_tid1);
		echo $this->unit->run($expResult1, $actResult1, "test edit dental treatment -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_tid2 = 6;
		$expResult2 = array();
		$actResult2 = $officer->edit_dental_treatment($in_tid2);
		echo $this->unit->run($expResult2, $actResult2, "test edit dental treatment -> false case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testo_editDentalTreatment_data(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_data = array('tid'=>5,'tName'=>'Extraction','cost'=>900);
		$expResult = true;
		$actResult = $officer->edit_dental_treatment_data($in_data);
		echo $this->unit->run($expResult, $actResult, "test edit dental treatment data -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testo_deleteDentalTreatment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_tid1 = 5;
		$officer->delete_treatment($in_tid1);
		
		$x = $this->load->model('Offiecer_Model');
		$x->tid = 1;
		$x->tName = 'Full mouth checkup';
		$x->cost = 0;
		$expResult1[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->tid = 2;
		$x2->tName = 'Composite filling';
		$x2->cost = 1000;
		$expResult1[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->tid = 3;
		$x3->tName = 'Fluoride application';
		$x3->cost = 400;
		$expResult1[2] = $x3;
		
		$x4 = $this->load->model('Offiecer_Model');
		$x4->tid = 4;
		$x4->tName = 'Consultation';
		$x4->cost = 0;
		$expResult1[3] = $x4;
		
		$actResult1 = $officer->get_treatment();
		echo $this->unit->run($expResult1, $actResult1, "test delete dental treatment data -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		}
	public function testo_get_treatment(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
				
		$x = $this->load->model('Offiecer_Model');
		$x->tid = 1;
		$x->tName = 'Full mouth checkup';
		$x->cost = 0;
		$expResult1[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->tid = 2;
		$x2->tName = 'Composite filling';
		$x2->cost = 1000;
		$expResult1[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->tid = 3;
		$x3->tName = 'Fluoride application';
		$x3->cost = 400;
		$expResult1[2] = $x3;
		
		$x4 = $this->load->model('Offiecer_Model');
		$x4->tid = 4;
		$x4->tName = 'Consultation';
		$x4->cost = 0;
		$expResult1[3] = $x4;
		
		$actResult1 = $officer->get_treatment();
		echo $this->unit->run($expResult1, $actResult1, "test delete dental treatment data -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		}
	public function testo_add_information(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_data1 = array('infoID'=>4,
					'type'=>'promo',
					'title'=>'Buy one get one free',
					'details'=>'Buy one fluoride application course now get one more course for free',
					'officerID'=>'OF001');
		$expResult = true;
		$actResult1 = $officer->add_information($in_data1);
		echo $this->unit->run($expResult, $actResult1, "test add promotion -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_data2 = array('infoID'=>5,
					'type'=>'info',
					'title'=>'Why full mouth checkup is important?',
					'details'=>'To checkup full mouth is help you to reduce the bad helth of your mouth',
					'officerID'=>'OF001');
		$actResult2 = $officer->add_information($in_data2);
		echo $this->unit->run($expResult, $actResult2, "test add information -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testo_edit_info(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_tid1 = 4;
		$expResult1 = array('infoID'=>4,
					'type'=>'promo',
					'title'=>'Buy one get one free',
					'details'=>'Buy one fluoride application course now get one more course for free',
					'officerID'=>'OF001');
		
		$actResult1 = $officer->edit_info($in_tid1);
		echo $this->unit->run($expResult1, $actResult1, "test call edit promotion -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_tid2 = 5;
		$expResult2 = array('infoID'=>5,
					'type'=>'info',
					'title'=>'Why full mouth checkup is important?',
					'details'=>'To checkup full mouth is help you to reduce the bad helth of your mouth',
					'officerID'=>'OF001');
		
		$actResult2 = $officer->edit_info($in_tid2);
		echo $this->unit->run($expResult2, $actResult2, "test call edit information -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testo_edit_info_data(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->infoID = 4;
		$x->type = 'promo';
		$x->title = 'Buy one get one free';
		$x->details = 'Buy one fluoride application course now get one more course for free available until the end of the year';
		$x->officerID = 'OF001';
		$in_data1 = $x; 
		
		$expResult = true;
		$actResult1 = $officer->edit_info_data($in_data1);
		echo $this->unit->run($expResult, $actResult1, "test call edit promotion data -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->infoID = 5;
		$x2->type = 'info';
		$x2->title = 'Why full mouth checkup is important?';
		$x2->details = 'To checkup full mouth is help you to reduce the bad helth of your mouth';
		$x2->officerID = 'OF001';
		$in_data2 = $x2; 
		
		$actResult2 = $officer->edit_info_data($in_data2);
		echo $this->unit->run($expResult, $actResult2, "test call edit information data -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult2);		
		}
	public function testo_delete_info(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_infoid1 = 4;
		
		$expResult1 = true;
		$actResult1 = $officer->delete_info($in_infoid1);
		echo $this->unit->run($expResult1, $actResult1, "test delete promotion -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_infoid2 = 5;
		
		$actResult2 = $officer->delete_info($in_infoid2);
		echo $this->unit->run($expResult1, $actResult2, "test delete promotion -> true case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		
		$in_infoid3 = 6;
		
		$expResult2 = false;
		$actResult3 = $officer->delete_info($in_infoid3);
		echo $this->unit->run($expResult2, $actResult3, "test delete promotion -> true case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult3);
		}
	public function testo_get_information(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$x = $this->load->model('Offiecer_Model');
		$x->infoID = 1;
		$x->type = 'promo';
		$x->title = 'Free checkup';
		$x->details = 'Full mouth checkup for free at the clinic';
		$x->officerID = 'OF001';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Offiecer_Model');
		$x2->infoID = 2;
		$x2->type = 'info';
		$x2->title = 'EF Line';
		$x2->details = 'EF Line is tooth braces for children between 4-15 years old';
		$x2->officerID = 'OF001';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Offiecer_Model');
		$x3->infoID = 3;
		$x3->type = 'promo';
		$x3->title = 'Whitening 30% off';
		$x3->details = 'End of the year sale, whitening treatment is noe 30% off';
		$x3->officerID = 'OF002';
		$expResult[2] = $x3;
		
		$actResult = $officer->get_information();
		echo $this->unit->run($expResult, $actResult, "test view all information -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testo_check_time(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_pid1 = 'P001';
		$expResult4 = array('0'=>'19:00:00');
		$actResult1 = $officer->check_time($in_pid1);
		echo $this->unit->run($expResult4, $actResult1, "test check time -> available date and time case");
		echo "exp >>> ";print_r($expResult4); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_pid2 = 'P002';
		$expResult1 = array('0'=>'not today');
		$actResult2 = $officer->check_time($in_pid2);
		echo $this->unit->run($expResult1, $actResult2, "test check time -> not today case");
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		
		$in_pid3 = 'P003';
		$expResult2 = array('0'=>'no appointment');
		$actResult3 = $officer->check_time($in_pid3);
		echo $this->unit->run($expResult2, $actResult3, "test check time -> no appointment case");
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult3);
		
		$in_pid4 = 'P004';
		$expResult3 = array('0'=>'you missed');
		$actResult4 = $officer->check_time($in_pid4);
		echo $this->unit->run($expResult3, $actResult4, "test check time -> you missed case");
		echo "exp >>> ";print_r($expResult3); echo "</br>";
		echo "act >>> ";print_r($actResult4);
		}
	public function testo_add_queue(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$in_pid1 = 'P001';
		$in_q = 1;
		$expResult = true;
		$actResult1 = $officer->add_queue($in_pid1, $in_q);
		echo $this->unit->run($expResult, $actResult1, "test add queue -> insert to null queue case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		
		$in_pid2 = 'P002';
		$actResult2 = $officer->add_queue($in_pid2, $in_q);
		echo $this->unit->run($expResult, $actResult2, "test add queue -> insert to not null queue case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		}
	public function testo_reset_queue(){
		$this->load->library("unit_test");
		$officer = new Officer_manage();
		
		$expResult = true;
		$actResult = $officer->reset_queue();
		echo $this->unit->run($expResult, $actResult, "test reset queue -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	}

?>