<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once APPPATH."manage/Visitor_manage.php";
class Visitor_Controller extends CI_Controller{
	
	function _construct(){
		parent ::construct();
		$this->jquery->script(base_url.'js/jquery.js',TRUE);
		}
		
	
	public function callCalendar(){
		$this->load->view('v_view_calendar');
		}

	public function view_information(){
		$visitor = new Visitor_manage();
		$data['info'] = $visitor->view_information();
		$this->load->view('v_view_info',$data);
		}
	public function callTreatment(){
		$visitor = new Visitor_manage();
		$data['treatment'] = $visitor->getAllTreatment();
		//print_r($data['treatment']);
		$data['result'] = 0;
		$this->load->view('v_cost_est', $data);
		}
	public function cost_est(){
		$patient = new Patient_manage();
		$dent_treat =array(
					'cost'=>$this->input->post('cost')
					);
		print_r($dent_treat);
		$result = $patient->calculate($dent_treat);
		print_r($result);
		$data['result']=$result;
		$data['treatment'] = $patient->getAllTreatment();
		$this->load->view('v_cost_est',$data);
		$result = 0;
			
		}
	}

?>