<?php
require_once APPPATH."manage/Dentist_manage.php";
class TestDentist_manage extends CI_controller{
	
	public function testLogin(){
		
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_user_f = "xxxx";
		$in_pass_f = "xxxx";
		$expResult1 = false;
		
		$actResult1 = $dentist->login($in_user_f, $in_pass_f);
		echo $this->unit->run($expResult1, $actResult1, "test login -> both incorrect");
		
		$in_user_t = "D001";
		$in_pass_t = "1234";
		$expResult2 = true;
		
		$actResult2 = $dentist->login($in_user_t, $in_pass_t);
		echo $this->unit->run($expResult2, $actResult2, "test login -> both correct");
		
		$actResult3 = $dentist->login($in_user_t,$in_pass_f);
		echo $this->unit->run($expResult1, $actResult3, "test login -> correct username, incorrect password");
		
		$actResult4 = $dentist->login($in_user_f,$in_pass_t);
		echo $this->unit->run($expResult1, $actResult4, "test login -> incorrect username, correct password");
		}
		
	public function testOwnCalendar(){
		
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_id_f = "xxxx";
		$expResult1 = null;
		
		$actResult1 = $dentist->getCalendarByDID($in_id_f);
		echo $this->unit->run($expResult1, $actResult1, "test view thier own schedule -> false case");
		
		$in_id_t = "D002";
		$x2 = $this->load->model('Dentist_Model');
		$x2->appointmentID = 5;
		$x2->patientID = 'P002';
		$x2->dentistID = 'D002';
		$x2->aDate = '2014-08-04';
		$x2->startTime = '11:00:00';
		$x2->endTime = '11:30:00';
		$x2->treatment = 'Tooth braces';
		$x2->description = '100 thb';
		$x2->submit = 'Submit';
		//Array ( [0] => stdClass Object ( [appointmentID] => 16 [patientID] => P0004 [userID] => dent001 [aDate] => 2014-07-04 [startTime] => 14:30:00 [endTime] => 15:00:00 [treatment] => aaaa [description] => aaaa ) )
		$expResult2[0] = $x2; 
		$actResult2 = $dentist->getCalendarByDID($in_id_t);
		
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test view thier own schedule -> true case");
		}

//progress 2

	public function testd_get_p_db(){
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$x = $this->load->model('Dentist_Model');
		$x->patientID = 'P001';
		$x->password = '1234';
		$x->f_name = 'Mickey';
		$x->l_name = 'Mouse';
		$x->age = 80;
		$x->gender = 1;
		$x->treatment = 'Braces';
		$x->address = 'Chaingmai Thailand';
		$x->tel = '053111111';
		$x->email = 'M.ky@hotmail.com';
		$x->submit = '0';
		$expResult[0] = $x;
		
		$x2 = $this->load->model('Dentist_Model');
		$x2->patientID = 'P002';
		$x2->password = '1111';
		$x2->f_name = 'Minnie';
		$x2->l_name = 'Mouse';
		$x2->age = 80;
		$x2->gender = 2;
		$x2->treatment = 'zepline';
		$x2->address = 'New York,USA';
		$x2->tel = '0120000000';
		$x2->email = 'M.Nie@hotmail.com';
		$x2->submit = '0';
		$expResult[1] = $x2;
		
		$x3 = $this->load->model('Dentist_Model');
		$x3->patientID = 'P003';
		$x3->password = '5555';
		$x3->f_name = 'Goofy';
		$x3->l_name = 'Goof';
		$x3->age = 4;
		$x3->gender = 1;
		$x3->treatment = 'EF line';
		$x3->address = 'California,USA';
		$x3->tel = '0230000000';
		$x3->email = 'GG@yahoo.com';
		$x3->submit = '0';
		$expResult[2] = $x3;
		
		$actResult = $dentist->get_p_db();
		
		echo $this->unit->run($expResult, $actResult, "test view all patient -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testd_follow_up(){
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_pid = 'P001';
		$expResult = 'P001';
		
		$actResult = $dentist->follow_up($in_pid);
		
		echo $this->unit->run($expResult, $actResult, "test view all patient -> true case");
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		}
	public function testd_follow_up_data(){
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_data = array('qid'=>14,
			'patientID'=>'P001',
			'dentistID'=>'D001',
			'question'=>'How are your composite filling? Is that fine?',
			'answer'=>null,
			'qDateTime'=>'2014-10-19 11:04:35',
			'aDateTime'=>null);
		$expResult = true;
		
		$actResult = $dentist->follow_up_data($in_data);
		echo "exp >>> ";print_r($expResult); echo "</br>";
		echo "act >>> ";print_r($actResult);
		echo $this->unit->run($expResult, $actResult, "test follow up data-> true case");
		
		}
	public function testd_getAllReply(){
		$this->load->library("unit_test");
		$dentist = new Dentist_manage();
		
		$in_did1 = 'D002';
		
		$x = $this->load->model('Patient_Model');
		$x->qid = 13;
		$x->patientID = 'P002';
		$x->dentistID = 'D002';
		$x->question = 'Your retainer is ready in next 3 days (2014-10-15) please come an pick it up at the clinic anytime';
		$x->answer = 'Ok, thank you very much';
		$x->qDateTime = '2014-10-12 09:15:22';
		$x->aDateTime = '2014-10-13 08:00:28';
		$expResult1[0] = $x;
		
		$actResult1 = $dentist->callAllReply($in_did1);
		echo "exp >>> ";print_r($expResult1); echo "</br>";
		echo "act >>> ";print_r($actResult1);
		echo $this->unit->run($expResult1, $actResult1, "test follow up data-> true case");
		
		$in_did2 = 'D001';
		$expResult2 = null;
		
		$actResult2 = $dentist->callAllReply($in_did2);
		echo "exp >>> ";print_r($expResult2); echo "</br>";
		echo "act >>> ";print_r($actResult2);
		echo $this->unit->run($expResult2, $actResult2, "test follow up data-> false case");
		}
	}
?>