<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once APPPATH."manage/Officer_manage.php";
class Officer_Controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
      function _construct(){
		parent ::construct();
		$this->jquery->script(base_url.'js/jquery/jquery.js',TRUE);  
	  }

public function get_db(){ 
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['user'] = $officer->get_db();
		$this->load->view("o_all_dent", $data);
	}
	
	public function get_p_db(){
		$officer = new Officer_manage();
		$data['ID']=$this->session->userdata('officer_id');
		$data['user'] = $officer->get_p_db();
		$this->load->view("o_all_patient", $data);
		}
	/*function test2($patientID){
		$officer = new Officer_manage();
		echo $officer->test2($patientID);
		}*/
	public function p_register(){
		$data3['ID']=$this->session->userdata('officer_id');
		if(strlen($data3['ID'])==0){
			$this->load->view('o_patient_regis');
		}
		else{
			$this->load->view('o_patient_regis', $data3);
			if($this->input->post('submit')){
			$officer = new Officer_manage();
			//$officer->p_register();
			$data = array(
    					'patientID'=> $this->input->post('patientID'),
						'password'=> md5($this->input->post('password')),
     					'f_name' => $this->input->post('f_name'),
     					'l_name' => $this->input->post('l_name'),
						'age'=>$this->input->post('age'),
						'gender'=>$this->input->post('gender'),
						'treatment'=>$this->input->post('treatment'),
						'address'=>$this->input->post('address'),
						'tel'=>$this->input->post('tel'),
						'email'=>$this->input->post('email'),
						'submit'=>$this->input->post('submit'));
			print_r($data);
			$result = $officer->p_register($data);
			if($result==true){
				$data2['user'] = $officer->get_p_db();
				$this->load->view("o_all_patient", $data2);
				}
			else{
				$this->load->view('o_patient_regis', $data);
				}
			}
		}
	}
	
	public function p_edit($patientID){
		//$data2['ID']=$this->session->userdata('officer_id');
//		if(strlen($data2['ID'])==0){
//			$this->load->view('o_patient_edit');
//		}
//		else{
			//$this->load->model('Offiecer_Model');
			//$data['user']=$this->Offiecer_Model->get_p_DataById($patientID);
			$officer = new Officer_manage();
			$data['user'] = $officer->p_edit($patientID);
			print_r($data['user']['gender']);
			print_r($data['user']['treatment']);
			$this->load->view('o_patient_edit',$data);
			//}
	}
	
	public function edit_data($patientID){
		//if($this->input->post('save')){
			$officer = new Officer_manage();
			$dataout['userout']=$officer->p_edit($patientID);
			//$pid = $dataout['userout']['patientID'];
			//print_r($pid);
			$data['patientID']=$dataout['userout']['patientID'];
			$data['password']=md5($this->input->post('password'));
			$data['f_name']=$this->input->post('f_name');
			$data['l_name']=$this->input->post('l_name');
			$data['age']=$this->input->post('age');
			$data['gender']=$dataout['userout']['gender'];
			$data['treatment']=$this->input->post('treatment');
			$data['address']=$this->input->post('address');
			$data['tel']=$this->input->post('tel');
			$data['email']=$this->input->post('email');
			$data['submit']=$this->input->post('save');
			$result = $officer->edit_data($data);
			if($result==true){
				$data['user'] = $officer->get_p_db();
				$this->load->view("o_all_patient", $data);
			}
		
	}
	function p_delete($patientID){
		/*$this->load->model('Offiecer_Model');
  		$this->Offiecer_Model->delete($patientID);
		echo $this->Offiecer_Model->get_p_data();*/
		$officer = new Officer_manage();
		$result = $officer->p_delete($patientID);
		if($result==true){
				$data['user'] = $officer->get_p_db();
				$this->load->view("o_all_patient", $data);
			}
	}
		function login(){ 
		
		$this->load->helper('form');
		$this->load->library('form_validation');

		 $this->form_validation->set_rules('officer_id', 'OfficerID', 'strip_tags|trim|required|xss_clean');

   $this->form_validation->set_rules('password', 'Password', 'required');
   
   	if($this->form_validation->run()== false){
		$this->load->view('officer_login');
	}
	else{
		$officerID = $this->input->post('officer_id');
		$password = $this->input->post('password');
		
	//$this->load->model('Offiecer_Model');
	//$result=$this->Offiecer_Model->login($userID,$password);
	$officer = new Officer_manage();
	$result = $officer->login($officerID, $password);
	if($result == true){
		
		redirect(base_url().'index.php/Officer');
	}
	else
	{
		$data['error_message'] ="Invalid userID or password";
		$this->load->view('officer_login',$data);
		
		}
		
		}
	
		
		} 
		
		function logout(){
		
			 $this->session->sess_destroy();
			 
			 redirect(base_url().'index.html');
			 
		}
		
		/*function myCalendar($year=null,$month=null){
			
			echo "My calendar";
			
			if(!$year){
				$year = date('Y');
			}
			if(!$month){
				$month = date('M');
			}
			
			$this->load->model('Offiecer_Model');
			if($day =$this->input->post('day')){
			
			$this->Offiecer_Model->addAppointment(
			"$year-$month-$day",
			$this->input->post('data'));
			}
			$data['calendar']=$this->Offiecer_Model->generate($year,$month);
			$this->load->view('calendar.html',$data);
			
		}*/
		
		function callCalendar(){
			$data['ID']=$this->session->userdata('officer_id');
			if(strlen($data['ID'])==0){
				$this->load->view('o_view_calendar');
				}
			else{
				
				$this->load->view('o_view_calendar',$data);
				}
			
			}
			
			
	public function d_register(){
		$data3['ID']=$this->session->userdata('officer_id');
		if(strlen($data3['ID'])==0){
			$this->load->view('o_dent_regis');
		}
		else{
			$this->load->view('o_dent_regis', $data3);
			if($this->input->post('submit')){
				$officer = new Officer_manage();
				$data = array(
    				'dentistID '=> $this->input->post('dentistID'),
					'password'=> md5($this->input->post('password')),
     				'f_name' => $this->input->post('f_name'),
     				'l_name' => $this->input->post('l_name'),
					'address'=>$this->input->post('address'),
					'tel'=>$this->input->post('tel'),
					'email'=>$this->input->post('email'),
					'submit'=>$this->input->post('submit'));
				$result = $officer->d_register($data);
				if($result==true){
					$data2['user'] = $officer->get_db();
					$this->load->view("o_all_dent",$data2);
					}
				else{
					$this->load->view('o_dent_regis', $data);
				}
			}
		}
	}
	
	public function d_edit($dentistID){
		$data2['ID']=$this->session->userdata('officer_id');
		if(strlen($data2['ID'])==0){
			$this->load->view('o_dent_edit');
		}
		else{
			//$this->load->model('Offiecer_Model');
			$officer = new Officer_manage();
			$data['user'] = $officer->d_edit($dentistID);
			$this->load->view('o_dent_edit',$data,$data2);
		}
	}
	
	public function d_edit_data($dentistID){
		$officer = new Officer_manage();
		$dataout['userout']=$officer->d_edit($dentistID);
		//print_r($dataout['userout']['dentistID']);
		$data['dentistID']=$dataout['userout']['dentistID'];
		$data['password']=md5($this->input->post('password'));
     	$data['f_name']=$this->input->post('f_name');
     	$data['l_name']=$this->input->post('l_name');
		$data['address']=$this->input->post('address');
		$data['tel']=$this->input->post('tel');
		$data['email']=$this->input->post('email');
		$result = $officer->d_edit_data($data);
		if($result==true){
			$data['user'] = $officer->get_db();
				$this->load->view("o_all_dent", $data);
			}
	}
	
	function d_delete($dentistID){
		$officer = new Officer_manage();
		$result = $officer->d_delete($dentistID);
		if($result==true){
				$data['user'] = $officer->get_db();
				$this->load->view("o_all_dent", $data);
			}
	}
	
	public function view_appointment(){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['user'] = $officer->view_appointment();
		$this->load->view("o_all_appointment", $data);
		}
	function test(){
		$officer = new Officer_manage();
		$dentistID = 'D002';
		$aDate = '2014-08-01';
		$startTime = '09:30:00';
		echo $officer->test($dentistID,$aDate,$startTime);
		}
	public function call_make_new(){
			$data['ID'] = $this->session->userdata('officer_id');
	$data['status']=null;
	if(strlen($data['ID'])==0){
		$this->load->view('o_make_appointment');
		}
	else{
		//$data['status']=null;
		$this->load->view('o_make_appointment',$data);
		}
		}
	public function make_appointment(){
	if($this->input->post('submit')){
			$officer = new Officer_manage();
			$data = array(
    			'patientID'=> $this->input->post('patientID'),
				'dentistID'=>$this->input->post('dentistID'),
				'aDate'=> $this->input->post('aDate'),
    			'startTime' => $this->input->post('startTime'),
    			'endTime' => $this->input->post('endTime'),
				'treatment'=>$this->input->post('treatment'),
				'description'=>$this->input->post('description'),
				'submit'=>$this->input->post('submit'));
			$result = $officer->make_appointment($data);
			print_r($result);
			if($result['result']==true){
				$data['user']=$officer->view_appointment();
				$this->load->view('o_all_appointment',$data);
				}
			else{
				//$this->make_new_error($result);
				$this->load->view('o_make_app_result',$result);
				//print_r($result);
				//echo 'false';
				}
			}
	}

	public function app_edit($appointmentID){
		$data2['ID']=$this->session->userdata('officer_id');
		if(strlen($data2['ID'])==0){
			$this->load->view('o_app_edit');
		}
		else{
			$officer = new Officer_manage();
			$data['user'] = $officer->app_edit($appointmentID);
			$this->load->view('o_app_edit',$data,$data2);
			}
	}
	
	public function app_edit_data($appointmentID){
		$officer = new Officer_manage();
		$dataout['dataout']=$officer->app_edit($appointmentID);
		$data['appointmentID']=$dataout['dataout']['appointmentID'];
		$data['patientID']=$this->input->post('patientID');
		$data['dentistID']=$this->input->post('dentistID');
		$data['aDate']=$this->input->post('aDate');
		$data['startTime']=$this->input->post('startTime');
		$data['endTime']=$this->input->post('endTime');
		$data['treatment']=$this->input->post('treatment');
		$data['description']=$this->input->post('description');
		$result = $officer->app_edit_data($data);
		if($result==true){
			$data['user']=$officer->view_appointment();
			$this->load->view('o_all_appointment',$data);
			}
	}
	function app_delete($appointmentID){
		$officer = new Officer_manage();
		$result = $officer->app_delete($appointmentID);
		if($result==true){
			$data['user']=$officer->view_appointment();
			$this->load->view('o_all_appointment',$data);
			}
	}
	
	function save_appointment($appointmentID){
		//$this->load->model('Offiecer_Model');
		//$data['user']=$this->Offiecer_Model->getAppointmentByAppointmentId($appointmentID);
		$officer = new Officer_manage();
		$data = $officer->save_appointment($appointmentID);
			$this->load->view('o_all_appointment',$data);
		}
		
	public function patientCalendar($patientID){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['user'] = $officer->patientCalendar($patientID);
		$this->load->view("o_p_own_schedule", $data);
		}
	
	public function dentistCalendar($dentistID){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['user'] = $officer->dentistCalendar($dentistID);
		$this->load->view("o_d_own_schedule", $data);
		}
	public function view_p_calendar(){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['user'] = $officer->get_p_db();
		$this->load->view("view_p_calendar", $data);
		}
	public function view_d_calendar(){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['user'] = $officer->get_db();
		$this->load->view("view_d_calendar", $data);
		}
		
	public function view_treatment_list(){
		$data['ID']=$this->session->userdata('officer_id');
		$data2['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['treatment'] = $officer->get_treatment();
		$this->load->view("o_all_dentalTreatment", $data,$data2);
		}	
		
	public function add_dental_treatment(){
		$data['ID']=$this->session->userdata('officer_id');
		if(strlen($data['ID'])==0){
			$this->load->view('o_add_dentalTreatment');
		}
		else{
			$this->load->view('o_add_dentalTreatment', $data);
			if($this->input->post('submit')){
			$officer = new Officer_manage();
			//$officer->p_register();
			$data = array(
    					'tid'=> $this->input->post('tid'),
						'tName'=> $this->input->post('tName'),
     					'cost' => $this->input->post('cost')
     					);
			print_r($data);
			$result = $officer->add_dental_treatment($data);
			if($result==true){
				$data['treatment'] = $officer->get_treatment();
				$this->load->view("o_all_dentalTreatment", $data);
				}
			else{
				$this->load->view('o_add_dentalTreatment', $data);
				}
			}
		}
		}
	public function edit_dental_treatment($tid){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
			$data['treatment'] = $officer->edit_dental_treatment($tid);
			$this->load->view('o_edit_dentalTreatment',$data);
		}
	public function edit_dental_treatment_data($tid){
			if($this->input->post('submit')){
			$officer = new Officer_manage();
			$dataout['out']=$officer->edit_dental_treatment($tid);
			$data = array(
    					'tid'=> $dataout['out']['tid'],
						'tName'=> $this->input->post('tName'),
     					'cost' => $this->input->post('cost')
     					);
			print_r($data);
			$result = $officer->edit_dental_treatment_data($data);
			if($result==true){
				$data2['treatment'] = $officer->get_treatment();
				$this->load->view("o_all_dentalTreatment", $data2);
				}
			else{
				$this->load->view('o_add_dentalTreatment', $data);
				}
			}
		
		}
	public function delete_dental_treatment($tid){
		$officer = new Officer_manage();
		$result = $officer->delete_treatment($tid);
		if($result==true){
			$data['treatment']=$officer->get_treatment();
			$this->load->view('o_all_dentalTreatment',$data);
			}
		}
	public function add_information(){
		$data['ID']=$this->session->userdata('officer_id');
		$this->load->view('o_add_info',$data);
		
		}
	public function add_info_data(){
		$data['ID']=$this->session->userdata('officer_id');
		if($this->input->post('submit')){
			$officer = new Officer_manage();
			$data = array(
    				'infoID'=> $this->input->post('infoID'),
					'type'=> $this->input->post('type'),
					'title'=> $this->input->post('title'),
     				'details' => $this->input->post('details'),
					'officerID'=> $this->input->post('officerID')
     				);
			print_r($data);
			$result = $officer->add_information($data);
			if($result==true){
				$data['info'] = $officer->get_information();
				$this->load->view('o_all_info', $data);
				}
			else{
				$this->load->view('o_all_info', $data);
				}
			}
		
		}
	public function callAllInformation(){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$data['info'] = $officer->get_information();
		$this->load->view('o_all_info', $data);
		//print_r($data2);
		}
	public function edit_info($infoID){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		if(strlen($data['ID'])==0){
			$this->load->view('o_edit_info');
		}
		else{
			$officer = new Officer_manage();
			$data['info'] = $officer->edit_info($infoID);
			$this->load->view('o_edit_info',$data);
			}
		}
	public function edit_info_data($infoID){
		$data2['ID']=$this->session->userdata('officer_id');
		if($this->input->post('submit')){
			$officer = new Officer_manage();
			$dataout['infoout'] = $officer->edit_info($infoID);
			$data['infoID']=$dataout['infoout']['infoID'];
			$data['type']=$this->input->post('type');
			$data['title']=$this->input->post('title');
			$data['details']=$this->input->post('details');
			$data['officerID']=$this->input->post('officerID');
			print_r($data);
			$result = $officer->edit_info_data($data);
			if($result==true){
				$data['info'] = $officer->get_information();
				print_r($data2);
				//print_r($data2);
				$this->load->view('o_all_info', $data);
				}
			else{
				$this->load->view('o_all_info', $data);
				}
			}
		}
	public function delete_info($infoID){
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$result = $officer->delete_info($infoID);
		if($result==true){
			$data['info'] = $officer->get_information();
		$this->load->view('o_all_info', $data);
			}
		}
	public function view_info_page(){
		$officer = new Officer_manage();
		$data['info'] = $officer->get_information();
		$this->load->view('o_view_info',$data);
		}
	/*This is the same in manage.
	public function gen_qr($patientID){
		$officer = new Officer_manage();
		$officer->gen_qr($patientID);
		$this->load->view('o_qr');
		//echo '<img src="'.base_url().'tes.png" />';
		}*/
	public function p_detail($patientID){
		
			$officer = new Officer_manage();
			$data['user'] = $officer->p_edit($patientID); //don't forget to change p_edit to other method
			$officer->gen_qr($patientID);
			$this->load->view('o_view_p',$data);
	}
/*	public function check_time(){
		$officer = new Officer_manage();
		$data['appointment']=$officer->view_appointment();
	
		//print_r($data+'</br>');
		$this->load->helper('date');
		$datestring = "%h:%i:%s";
		$time = time();
		$data['datetime'] = mdate($datestring, $time);
		//print_r($data['datetime']);
		$result = array();
		foreach ($data['appointment'] as $key => $value) {
			if($value->startTime>=$data['datetime']){
   			$result[] = $value->startTime;
		}
		}
		print_r($result);
		
		}*/
	public function call_checktime(){
		
		$this->load->view('o_checktime');
		}
	public function check_time(){
		$officer = new Officer_manage();
		$data['result']=null;
		if($this->input->post('submit')){
			$pid=$this->input->post('patientID');
			$result = $officer->check_time($pid);
			//print_r($result);
			$data['result']=$result;
			$this->load->view('o_checktime_result',$data);
			}
			print_r($data['result']);
		}
	public function call_queueing(){
		$data['ID']=$this->session->userdata('officer_id');
		$this->load->view('o_check_queue',$data);
		}
	public function queueing(){
		$officer = new Officer_manage();
		$data['ID']=$this->session->userdata('officer_id');
		if($this->input->post('submit')){
			$pid=$this->input->post('patientID');
			//$data['pid']=$pid;
			$data['result'] = $officer->check_time($pid);
			$data['pid']=$pid;
			
			$this->load->helper('date');
			$timestring = "%H:%i:%s";
			$time = time();
			$human = unix_to_human($time, TRUE, 'eu');
			$unix = human_to_unix($human);
			$dataT['time'] = mdate($timestring, $unix);
			$datestring = "%Y-%m-%d";
			$dataT['date'] = mdate($datestring, $time);
		
			foreach ($data['result'] as $key => $value) {
				$count=0;
				if($value!='no appointment'&&$value!='not today'&&$value!='you missed'){
					$data['allq'] = $officer->all_queue();
					//print_r($data['allq']);
					$this->load->view('o_add_queue',$data);
					break;
					}
				else{
					$this->load->view('o_checktime_result',$data);
					}
				
				}
			}
		}

	public function add_queue($pid,$q){
		$officer = new Officer_manage();
		$data['pid']=$pid;
		$data['result']=$officer->add_queue($pid,$q);
		if($data['result']==true){
			$data['allq'] = $officer->all_queue();
			$this->load->view('o_add_queue',$data);
			}
		}
	public function call_addqueue(){
		$officer = new Officer_manage();
		$data['allq'] = $officer->all_queue();
		//print_r($data['allq']);
		$this->load->view('o_add_queue',$data);
			}
	public function confirm_reset_queue(){
		$data['ID']=$this->session->userdata('officer_id');
		$this->load->view('o_reset_queue',$data);
		}
	public function reset_queue(){
		
		$data['ID']=$this->session->userdata('officer_id');
		$officer = new Officer_manage();
		$result = $officer->reset_queue();
		if($result==true){
			$data['allq'] = $officer->all_queue();
			$this->load->view('o_check_queue',$data);
			}
		}
	public function callMain(){
		$data['ID']=$this->session->userdata('officer_id');
		$this->load->view('o_index', $data);
		}
		
	public function testmake_appointment(){
		$result['status']=null;
		$this->load->view('o_make_appointment',$result);
		if($this->input->post('submit')){
			$officer = new Officer_manage();
			$data = array(
    			'patientID'=> $this->input->post('patientID'),
				'dentistID'=>$this->input->post('dentistID'),
				'aDate'=> $this->input->post('aDate'),
    			'startTime' => $this->input->post('startTime'),
    			'endTime' => $this->input->post('endTime'),
				'treatment'=>$this->input->post('treatment'),
				'description'=>$this->input->post('description'),
				'submit'=>$this->input->post('submit'));
			$result = $officer->make_appointment2($data);
			print_r($result);
			if($result['result']==true){
				
				$data['user']=$officer->view_appointment();
				$this->load->view('o_all_appointment',$data);
				//echo 'true';
				}
			else{
				$this->load->view('o_make_app_result',$result);
				print_r($result);
				//echo 'false';
				}
		}
		}
	public function testcheck_time($patientID){
		$officer = new Officer_manage();
		$result = $officer->check_time($patientID);
		//print_r($result);
		$pid=$patientID;
			//$data['pid']=$pid;
			$data['result'] = $officer->check_time($pid);
			$data['pid']=$pid;
			$count_result = count($data['result']);
			//print_r($data['result']);
			for($i=0; $i<$count_result;$i++){
				if($data['result'][$i]=='ok'){
					$data['allq'] = $officer->all_queue();
					//print_r($data['allq']);
					$this->load->view('o_add_queue',$data);
					print_r('ok');
					break;
					}
				
				else{
					$this->call_queueing();
					//$this->load->view('o_checktime_result',$data);
					//print_r('else');
					}
				}
		}
	
		

	}
	
	